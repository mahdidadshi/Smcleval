// سرویس‌ورکر میز کار ایجنت اسمارت مانی
// استراتژی: صفحات = شبکه‌اول (همیشه تازه) با پشتیبان آفلاین؛ فایل‌های استاتیک = کش با به‌روزرسانی پس‌زمینه؛ API = هرگز کش نمی‌شود
const CACHE = "smc-desk-v1";

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
      await self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return; // فونت CDN و منابع خارجی به مرورگر سپرده می‌شود
  if (url.pathname.startsWith("/api/")) return; // دیتای بازار همیشه زنده
  if (url.pathname.startsWith("/_next/webpack-hmr")) return;

  // ناوبری صفحات: شبکه اول، در صورت قطعی اینترنت آخرین نسخه صفحه
  if (request.mode === "navigate") {
    event.respondWith(
      (async () => {
        try {
          const res = await fetch(request);
          const cache = await caches.open(CACHE);
          cache.put("/", res.clone());
          return res;
        } catch {
          const cache = await caches.open(CACHE);
          return (await cache.match("/")) || (await cache.match(request)) || Response.error();
        }
      })()
    );
    return;
  }

  // استاتیک‌ها: اول کش، همزمان به‌روزرسانی در پس‌زمینه
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE);
      const cached = await cache.match(request);
      const network = fetch(request)
        .then((res) => {
          if (res && res.ok) cache.put(request, res.clone());
          return res;
        })
        .catch(() => undefined);
      return cached || (await network) || Response.error();
    })()
  );
});
