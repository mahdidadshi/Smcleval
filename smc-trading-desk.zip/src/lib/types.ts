export type Market = "crypto" | "stock" | "forex";
export type Timeframe = "1m" | "5m" | "15m" | "30m" | "1h" | "4h" | "1d" | "1w";
export type Signal = "strong_buy" | "buy" | "neutral" | "sell" | "strong_sell";

export interface Candle {
  time: number; // unix seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface KlinesResponse {
  symbol: string;
  market: Market;
  timeframe: Timeframe;
  candles: Candle[];
  liquidityLevels: { price: number; type: "above" | "below" }[];
  quote: {
    last: number;
    changePct: number;
    periodHigh: number;
    periodLow: number;
    volume: number;
  };
}

export interface StyleResult {
  id: string;
  name: string;
  weight: number;
  score: number; // -100..100
  signal: Signal;
  reasons: string[];
}

export interface AgentVerdict {
  signal: Signal;
  confidence: number; // 0..100
  entryMin: number;
  entryMax: number;
  entryType: "limit" | "market";
  stopLoss: number;
  targets: number[];
  riskReward: number;
  summary: string;
  reasoning: string[];
  source: "ai" | "fallback";
}

export interface LiquidityPool {
  price: number;
  side: "above" | "below";
  touches: number;
  status: "unswept" | "swept" | "broken";
  eventBarsAgo: number;
}

export interface SweepEvent {
  dir: "bull" | "bear"; // bull = sweep of lows (bullish signal)
  barsAgo: number;
  price: number;
  kind: string;
}

export interface TrapEvent {
  name: string;
  dir: "bull" | "bear"; // dir of the resulting signal
  barsAgo: number;
}

export interface StructureEvent {
  type: "BOS" | "CHoCH";
  dir: "bull" | "bear";
  barsAgo: number;
}

export interface SessionInfo {
  sessionName: string;
  killzone: boolean;
  asianHigh: number | null;
  asianLow: number | null;
  sweepOfAsian: { dir: "bull" | "bear"; barsAgo: number } | null;
  breakout: "above" | "below" | null;
}

export interface VolumeInfo {
  poc: number;
  hvn: number[];
  lvn: number[];
  priceVsPoc: "above" | "below";
  delta10: number; // -100..100
  volumeRatio: number;
  climax: { dir: "bull" | "bear"; barsAgo: number } | null;
  absorption: { dir: "bull" | "bear"; barsAgo: number } | null;
}

export interface ObInfo {
  type: "bull" | "bear";
  top: number;
  bottom: number;
  barsAgo: number;
  mitigated: boolean;
}

export interface FvgInfo {
  type: "bull" | "bear";
  top: number;
  bottom: number;
  barsAgo: number;
  filled: boolean;
}

export interface SmcSnapshot {
  trend: "bullish" | "bearish" | "ranging";
  lastEvent: StructureEvent | null;
  lastSwingHigh: number | null;
  lastSwingLow: number | null;
  avgRange: number;
  poolsAbove: LiquidityPool[];
  poolsBelow: LiquidityPool[];
  recentSweeps: SweepEvent[];
  traps: TrapEvent[];
  roundLevel: number | null;
  sessions: SessionInfo | null;
  volume: VolumeInfo;
  obs: ObInfo[];
  fvgs: FvgInfo[];
  premiumDiscount: { eq: number; zone: "premium" | "discount" | "equilibrium" };
  cyclePhase: string;
}

export interface AnalysisResponse {
  symbol: string;
  symbolName: string;
  market: Market;
  timeframe: Timeframe;
  lastPrice: number;
  styles: StyleResult[];
  techScore: number;
  smc: SmcSnapshot;
  agent: AgentVerdict;
  generatedAt: number;
}

export interface SymbolInfo {
  symbol: string;
  name: string;
}
