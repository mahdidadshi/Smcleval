import ZAI from "z-ai-web-dev-sdk";
import type { AgentVerdict, Signal, SmcSnapshot, StyleResult } from "./types";

const SIGNAL_FA: Record<Signal, string> = {
  strong_buy: "خرید قوی",
  buy: "خرید",
  neutral: "خنثی",
  sell: "فروش",
  strong_sell: "فروش قوی",
};

interface AgentInput {
  symbol: string;
  symbolName: string;
  timeframe: string;
  lastPrice: number;
  smc: SmcSnapshot;
  styles: StyleResult[];
  techScore: number;
}

const SYSTEM_PROMPT = `تو «ایجنت ارشد اسمارت مانی (SMC/ICT)» هستی؛ تحلیل‌گری که بازار را نه با اندیکاتور، بلکه با نقدینگی، ساختار بازار، اردربلاک‌ها، شکاف‌های قیمتی (FVG)، سشن‌ها، پروفایل والیوم و رفتار روانی جمعیت می‌خواند.

منطق معاملاتی تو:
- هدف قیمت = استخرهای نقدینگی نشکسته (سقف/کف‌هایی که هنوز شکار نشده‌اند). قیمت به سمت نقدینگی حرکت می‌کند.
- حد ضرر = پشت سطحی که تازه شکار شده یا پشت سوینگ ساختاری، با بافر حدود ۰.۳ برابر میانگین دامنه کندل‌ها (avgRange). هرگز استاپ را داخل محدوده نوسان عادی نگذار — استاپِ نزدیک اول شکار می‌شود بعد قیمت در جهت تحلیل حرکت می‌کند.
- اگر SFP/شکار نقدینگی تازه رخ داده و ساختار هم هم‌جهت است، این بالاترین کیفیت ورود است؛ استاپ حتماً «پشت» ویک همان شکار باشد نه بالاتر از آن.
- ورود در اردربلاک نشکسته یا FVG نشکسته یا زون دیسکانت (برای خرید) / پرمیوم (برای فروش) کیفیت معامله را بالا می‌برد.
- هرگز قیمت را تعقیب نکن: اگر قیمت از زون نهادی/نقطه شلیک فاصله گرفته، ناحیه ورود لیمیت را روی پولبک به زون بگذار، نه مارکت در انتهای موج.
- فنر (Spring) و آپثراست (Upthrust) و شکار رنج آسیا، تله‌های طلایی هستند.
- وقتی والیوم (دلتا/کلایمکس/جذب) با ساختار هم‌جهت است، اعتماد بیشتری داشته باش؛ وقتی تناقض دارد احتیاط کن.

قوانین خروجی:
1. فقط و فقط یک JSON معتبر برگردان؛ هیچ متن یا markdown اضافه ننویس.
2. برای خرید: stopLoss کمتر از قیمت فعلی، حتماً زیر کف شکار نقدینگی تازه/سوینگ ساختاری منهای ۰.۳ avgRange و حداقل ۰.۸ avgRange فاصله از ورود؛ اهداف ترجیحاً روی نقدینگی‌های نشکسته بالای قیمت (poolsAbove) و صعودی مرتب.
3. برای فروش: stopLoss بیشتر از قیمت فعلی، حتماً بالای سقف شکار نقدینگی تازه/سوینگ ساختاری بعلاوه ۰.۳ avgRange و حداقل ۰.۸ avgRange فاصله از ورود؛ اهداف روی نقدینگی‌های نشکسته زیر قیمت (poolsBelow) و نزولی مرتب.
4. برای خنثی: ناحیه ورود حول قیمت فعلی و اهداف بر اساس نزدیک‌ترین نقدینگی‌ها.
5. ضدتعقیب: برای خرید entryMax حداکثر ۰.۷ avgRange بالای قیمت فعلی؛ برای فروش entryMin حداکثر ۰.۷ avgRange پایین قیمت فعلی. اگر قیمت رانده شده، ورود لیمیت روی پولبک به اردربلاک/FVG بده.
6. نسبت ریسک به بازده حداقل 1.3؛ اگر نقدینگی نزدیک است، معامله نگیر و neutral بده.
7. confidence بین 5 تا 95: هم‌جهتی سبک‌ها و تازگی شکار نقدینگی آن را بالا می‌برد.
8. summary و reasoning کاملاً فارسی و حرفه‌ای؛ به اعداد واقعی (سطوح نقدینگی، رویدادها) ارجاع بده.

ساختار JSON:
{
  "signal": "strong_buy" | "buy" | "neutral" | "sell" | "strong_sell",
  "confidence": <5..95>,
  "entryMin": <عدد>,
  "entryMax": <عدد>,
  "entryType": "limit" یا "market",
  "stopLoss": <عدد>,
  "targets": [<t1>, <t2>, <t3>],
  "riskReward": <عدد>,
  "summary": "<۲ تا ۴ جمله فارسی>",
  "reasoning": ["<دلیل ۱>", "<دلیل ۲>", "<دلیل ۳>"]
}`;

function buildPayload(input: AgentInput): string {
  const { smc: s } = input;
  const payload = {
    نماد: `${input.symbolName} (${input.symbol})`,
    تایم_فریم: input.timeframe,
    قیمت_فعلی: Number(input.lastPrice.toFixed(6)),
    میانگین_دامنه_کندل: Number(s.avgRange.toPrecision(4)),
    ساختار_بازار: {
      روند: s.trend === "bullish" ? "صعودی" : s.trend === "bearish" ? "نزولی" : "رنج",
      آخرین_رویداد: s.lastEvent
        ? `${s.lastEvent.type} ${s.lastEvent.dir === "bull" ? "صعودی" : "نزولی"} در ${s.lastEvent.barsAgo} کندل قبل`
        : null,
      سوینگ_بالا: s.lastSwingHigh ? Number(s.lastSwingHigh.toFixed(6)) : null,
      سوینگ_پایین: s.lastSwingLow ? Number(s.lastSwingLow.toFixed(6)) : null,
    },
    نقدینگی_بالای_قیمت_نشکسته: s.poolsAbove.map((p) => ({ سطح: Number(p.price.toFixed(6)), برخورد: p.touches })),
    نقدینگی_زیر_قیمت_نشکسته: s.poolsBelow.map((p) => ({ سطح: Number(p.price.toFixed(6)), برخورد: p.touches })),
    شکارهای_اخیر_نقدینگی: s.recentSweeps.map((w) => ({
      جهت_سیگنال: w.dir === "bull" ? "صعودی" : "نزولی",
      سطح: Number(w.price.toFixed(6)),
      کندل_قبل: w.barsAgo,
      نوع: w.kind,
    })),
    تله‌های_روانی: s.traps.map((t) => ({ نام: t.name, جهت_سیگنال: t.dir === "bull" ? "صعودی" : "نزولی", کندل_قبل: t.barsAgo })),
    سطح_روانی_عدد_رند: s.roundLevel ? Number(s.roundLevel.toFixed(6)) : null,
    سشن‌ها: s.sessions
      ? {
          سشن_جاری: s.sessions.sessionName,
          کیل_زون: s.sessions.killzone,
          سقف_آسیا: s.sessions.asianHigh ? Number(s.sessions.asianHigh.toFixed(6)) : null,
          کف_آسیا: s.sessions.asianLow ? Number(s.sessions.asianLow.toFixed(6)) : null,
          شکار_رنج_آسیا: s.sessions.sweepOfAsian
            ? `${s.sessions.sweepOfAsian.dir === "bull" ? "کف" : "سقف"} شکار شد در ${s.sessions.sweepOfAsian.barsAgo} کندل قبل`
            : null,
          شکست_رنج: s.sessions.breakout === "above" ? "بالا" : s.sessions.breakout === "below" ? "پایین" : null,
        }
      : null,
    والیوم: {
      POC: Number(s.volume.poc.toFixed(6)),
      قیمت_نسبت_به_POC: s.volume.priceVsPoc === "above" ? "بالا" : "پایین",
      دلتای_۱۰_کندل: Number(s.volume.delta10.toFixed(1)),
      حجم_به_میانگین: Number(s.volume.volumeRatio.toFixed(2)),
      کلایمکس: s.volume.climax ? `${s.volume.climax.dir === "bull" ? "صعودی" : "نزولی"} در ${s.volume.climax.barsAgo} کندل قبل` : null,
      جذب_سفارش: s.volume.absorption ? `${s.volume.absorption.dir === "bull" ? "صعودی" : "نزولی"}` : null,
    },
    اردربلاک‌های_نشکسته: s.obs.map((o) => ({
      نوع: o.type === "bull" ? "صعودی" : "نزولی",
      از: Number(o.bottom.toFixed(6)),
      تا: Number(o.top.toFixed(6)),
      کندل_قبل: o.barsAgo,
    })),
    FVGهای_نشکسته: s.fvgs.map((f) => ({
      نوع: f.type === "bull" ? "صعودی" : "نزولی",
      از: Number(f.bottom.toFixed(6)),
      تا: Number(f.top.toFixed(6)),
      کندل_قبل: f.barsAgo,
    })),
    پرمیوم_دیسکانت: {
      تعادل: Number(s.premiumDiscount.eq.toFixed(6)),
      وضعیت: s.premiumDiscount.zone === "premium" ? "پرمیوم" : s.premiumDiscount.zone === "discount" ? "دیسکانت" : "تعادل",
    },
    فاز_چرخه_بازار: s.cyclePhase,
    سبک‌های_تحلیلی: input.styles.map((st) => ({ سبک: st.name, سیگنال: SIGNAL_FA[st.signal], امتیاز: Math.round(st.score) })),
    امتیاز_ترکیبی: Math.round(input.techScore),
  };
  return `داده‌های اسمارت مانی سیستم:\n${JSON.stringify(payload, null, 1)}\n\nتصمیم نهایی معاملاتی را فقط به صورت JSON بده.`;
}

function extractJson(text: string): Record<string, unknown> | null {
  if (!text) return null;
  const cleaned = text.trim().replace(/```json/gi, "").replace(/```/g, "");
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    return JSON.parse(cleaned.slice(start, end + 1));
  } catch {
    return null;
  }
}

const num = (v: unknown, fb: number): number => {
  const n = Number(v);
  return isFinite(n) && n > 0 ? n : fb;
};

export function fallbackVerdict(input: AgentInput): AgentVerdict {
  const { lastPrice, smc: s, techScore } = input;
  const r = s.avgRange > 0 ? s.avgRange : lastPrice * 0.008;
  const signal: Signal =
    techScore >= 60 ? "strong_buy" : techScore >= 25 ? "buy" : techScore <= -60 ? "strong_sell" : techScore <= -25 ? "sell" : "neutral";
  const isBuyDir = techScore >= 0;

  const entryMin = lastPrice - (isBuyDir ? 0.2 * r : -0.05 * r);
  const entryMax = lastPrice + (isBuyDir ? 0.05 * r : -0.2 * r);
  const midEntry = (entryMin + entryMax) / 2;

  // استاپ ساختاری: پشت ویک شکار نقدینگی تازه یا سوینگ ساختاری + بافر — نه داخل محدوده نوسان
  let stopLoss: number;
  let targets: number[];
  if (isBuyDir) {
    const cands: number[] = [];
    if (s.lastSwingLow != null && s.lastSwingLow < lastPrice) cands.push(s.lastSwingLow);
    for (const w of s.recentSweeps) if (w.dir === "bull" && w.barsAgo <= 8 && w.price < lastPrice) cands.push(w.price);
    const base = cands.length ? Math.min(...cands) : lastPrice - 1.6 * r;
    stopLoss = base - Math.max(0.3 * r, 0.05 * (lastPrice - base));
    if (midEntry - stopLoss < 0.8 * r) stopLoss = midEntry - 0.8 * r; // استاپ کمعرض اول شکار می‌شود
    const poolTargets = s.poolsAbove.map((p) => p.price).filter((p) => p > lastPrice).sort((a, b) => a - b);
    targets = [...poolTargets];
    let nxt = lastPrice + 2 * r;
    while (targets.length < 3) {
      targets.push(nxt);
      nxt += 1.7 * r;
    }
    targets = targets.slice(0, 3);
  } else {
    const cands: number[] = [];
    if (s.lastSwingHigh != null && s.lastSwingHigh > lastPrice) cands.push(s.lastSwingHigh);
    for (const w of s.recentSweeps) if (w.dir === "bear" && w.barsAgo <= 8 && w.price > lastPrice) cands.push(w.price);
    const base = cands.length ? Math.max(...cands) : lastPrice + 1.6 * r;
    stopLoss = base + Math.max(0.3 * r, 0.05 * (base - lastPrice));
    if (stopLoss - midEntry < 0.8 * r) stopLoss = midEntry + 0.8 * r;
    const poolTargets = s.poolsBelow.map((p) => p.price).filter((p) => p < lastPrice).sort((a, b) => b - a);
    targets = [...poolTargets];
    let nxt = lastPrice - 2 * r;
    while (targets.length < 3) {
      targets.push(nxt);
      nxt -= 1.7 * r;
    }
    targets = targets.slice(0, 3);
  }

  const risk = Math.abs(midEntry - stopLoss);
  const reward = Math.abs(targets[0] - midEntry);
  const confidence = Math.min(85, Math.max(40, 40 + Math.abs(techScore) * 0.45));

  return {
    signal,
    confidence: Math.round(confidence),
    entryMin: Math.min(entryMin, entryMax),
    entryMax: Math.max(entryMin, entryMax),
    entryType: "market",
    stopLoss,
    targets,
    riskReward: risk > 0 ? Number((reward / risk).toFixed(2)) : 1.5,
    summary:
      signal === "neutral"
        ? "نقدینگی و ساختار بازار جهت واضحی نشان نمی‌دهند و سبک‌ها در تضادند. تا شکار نقدینگی در یکی از طرفین یا شکست ساختاری صبر کنید."
        : `بر اساس امتیاز ترکیبی سیستم (${Math.round(techScore)}) و موقعیت نقدینگی، سناریوی ${isBuyDir ? "صعودی با هدف استخرهای نقدینگی بالای قیمت" : "نزولی با هدف استخرهای نقدینگی زیر قیمت"} اولویت دارد. حد ضرر پشت نقدینگی/سوینگ ساختاری تنظیم شده است.`,
    reasoning: [
      `روند ساختاری: ${s.trend === "bullish" ? "صعودی" : s.trend === "bearish" ? "نزولی" : "رنج"}`,
      `نقدینگی نشکسته: ${s.poolsAbove.length} استخر بالا و ${s.poolsBelow.length} استخر پایین قیمت`,
      `فاز چرخه بازار: ${s.cyclePhase}`,
    ],
    source: "fallback",
  };
}

function validateVerdict(raw: Record<string, unknown>, input: AgentInput): AgentVerdict | null {
  const validSignals: Signal[] = ["strong_buy", "buy", "neutral", "sell", "strong_sell"];
  const signal = raw.signal as Signal;
  if (!validSignals.includes(signal)) return null;

  const price = input.lastPrice;
  const r = input.smc.avgRange > 0 ? input.smc.avgRange : price * 0.008;
  let entryMin = num(raw.entryMin, price);
  let entryMax = num(raw.entryMax, price);
  let stopLoss = num(raw.stopLoss, price - 1.5 * r);
  let targets = Array.isArray(raw.targets) ? raw.targets.map((t) => num(t, price)).slice(0, 3) : [];
  if (targets.length !== 3) targets = fallbackVerdict(input).targets;

  const far = (v: number) => Math.abs(v - price) / price > 0.25;
  if (far(entryMin) || far(entryMax) || far(stopLoss) || targets.some(far)) return null;
  if (entryMin > entryMax) [entryMin, entryMax] = [entryMax, entryMin];

  const isBuy = signal === "buy" || signal === "strong_buy";
  const isSell = signal === "sell" || signal === "strong_sell";
  if (isBuy) {
    if (stopLoss >= price * 0.9995) return null;
  } else if (isSell) {
    if (stopLoss <= price * 1.0005) return null;
  }

  // ── ضدتعقیب (anti-chase): ورود نباید در انتهای موج باشد — سود اصلی از دست می‌رود ──
  if (isBuy) {
    if (entryMax > price + 0.7 * r) {
      entryMax = price + 0.35 * r;
      if (entryMin > entryMax) entryMin = Math.max(price - 1.8 * r, entryMax - 1.2 * r);
    }
    if (entryMin < price - 2.5 * r) entryMin = price - 2.5 * r;
  } else if (isSell) {
    if (entryMin < price - 0.7 * r) {
      entryMin = price - 0.35 * r;
      if (entryMax < entryMin) entryMax = Math.min(price + 1.8 * r, entryMin + 1.2 * r);
    }
    if (entryMax > price + 2.5 * r) entryMax = price + 2.5 * r;
  }
  if (entryMin > entryMax) [entryMin, entryMax] = [entryMax, entryMin];

  const midEntry = (entryMin + entryMax) / 2;

  // ── استاپ ساختاری: پشت ویک شکار نقدینگی تازه یا سوینگ ساختاری + بافر ──
  // استاپ LLM اگر داخل محدوده شکار/بالاتر از ساختار بود، اجباری به ساختار کشیده می‌شود
  // (استاپِ داخل نوسان عادی اول تاچ می‌شود بعد قیمت در جهت سیگنال حرکت می‌کند)
  const smc = input.smc;
  if (isBuy) {
    const cands: number[] = [];
    if (smc.lastSwingLow != null && smc.lastSwingLow < price) cands.push(smc.lastSwingLow);
    for (const w of smc.recentSweeps) if (w.dir === "bull" && w.barsAgo <= 8 && w.price < price) cands.push(w.price);
    const base = cands.length ? Math.min(...cands) : price - 1.6 * r;
    const structural = base - Math.max(0.3 * r, 0.05 * (price - base));
    if (stopLoss > structural) stopLoss = structural;
    if (midEntry - stopLoss < 0.8 * r) stopLoss = midEntry - 0.8 * r; // استاپ کمعرض اول شکار می‌شود
    // استاپ باید پایین‌تر از «پایین‌ترین نقطه ورود» هم باشد — وگرنه پولبک به ناحیه ورود، استاپ را تاچ می‌کند
    if (entryMin - stopLoss < 0.45 * r) stopLoss = entryMin - 0.45 * r;
    if (midEntry - stopLoss > 3.6 * r) return null; // بیش از حد دور — ورود بی‌کیفیت
  } else if (isSell) {
    const cands: number[] = [];
    if (smc.lastSwingHigh != null && smc.lastSwingHigh > price) cands.push(smc.lastSwingHigh);
    for (const w of smc.recentSweeps) if (w.dir === "bear" && w.barsAgo <= 8 && w.price > price) cands.push(w.price);
    const base = cands.length ? Math.max(...cands) : price + 1.6 * r;
    const structural = base + Math.max(0.3 * r, 0.05 * (base - price));
    if (stopLoss < structural) stopLoss = structural;
    if (stopLoss - midEntry < 0.8 * r) stopLoss = midEntry + 0.8 * r;
    // استاپ باید بالاتر از «بالاترین نقطه ورود» هم باشد — وگرنه پولبک به ناحیه ورود، استاپ را تاچ می‌کند
    if (stopLoss - entryMax < 0.45 * r) stopLoss = entryMax + 0.45 * r;
    if (stopLoss - midEntry > 3.6 * r) return null;
  }

  // ── ترتیب اهداف؛ اگر بعد از اصلاحات به‌هم ریخت یا RR کم شد، با R چندبرابر بازتنظیم می‌شود ──
  const ordered = isBuy
    ? targets[0] < targets[1] && targets[1] < targets[2]
    : isSell
      ? targets[0] > targets[1] && targets[1] > targets[2]
      : true;
  const firstBeyond = isBuy ? targets[0] > entryMax : isSell ? targets[0] < entryMin : true;
  const risk = Math.abs(midEntry - stopLoss);
  let reward = Math.abs(targets[0] - midEntry);
  let rr = risk > 0 ? reward / risk : 0;

  // حداقل نسبت ریسک به بازده 1.2 برای سیگنال‌های جهت‌دار — در غیر این صورت اهداف با R چندبرابر بازتنظیم می‌شوند
  if ((isBuy || isSell) && risk > 0 && (!ordered || !firstBeyond || rr < 1.2)) {
    const dir = isBuy ? 1 : -1;
    targets = [1.5, 2.5, 4].map((m) => midEntry + dir * risk * m);
    reward = Math.abs(targets[0] - midEntry);
    rr = reward / risk;
  }
  if (rr < 0.4) return null;

  const confidence = Math.min(95, Math.max(5, Math.round(Number(raw.confidence) || 50)));
  const summary = typeof raw.summary === "string" && raw.summary.trim() ? raw.summary.trim() : "";
  const reasoning = Array.isArray(raw.reasoning)
    ? (raw.reasoning as unknown[]).filter((x): x is string => typeof x === "string" && x.trim().length > 0).slice(0, 6)
    : [];
  if (!summary || reasoning.length === 0) return null;

  return {
    signal,
    confidence,
    entryMin,
    entryMax,
    entryType: raw.entryType === "market" ? "market" : "limit",
    stopLoss,
    targets,
    riskReward: Number(rr.toFixed(2)),
    summary,
    reasoning,
    source: "ai",
  };
}

export async function runAgent(input: AgentInput): Promise<AgentVerdict> {
  try {
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "assistant", content: SYSTEM_PROMPT },
        { role: "user", content: buildPayload(input) },
      ],
      thinking: { type: "disabled" },
    });
    const text = completion.choices[0]?.message?.content ?? "";
    const parsed = extractJson(text);
    if (!parsed) throw new Error("JSON parse failed");
    const validated = validateVerdict(parsed, input);
    if (!validated) throw new Error("Validation failed");
    return validated;
  } catch (err) {
    console.error("[smc-agent] falling back to system verdict:", err instanceof Error ? err.message : err);
    return fallbackVerdict(input);
  }
}
