import type { Candle, Market, SymbolInfo, Timeframe } from "./types";
import { SYMBOLS } from "./symbols-client";

export { SYMBOLS };

const BINANCE_INTERVALS: Record<Timeframe, string> = {
  "1m": "1m",
  "5m": "5m",
  "15m": "15m",
  "30m": "30m",
  "1h": "1h",
  "4h": "4h",
  "1d": "1d",
  "1w": "1w",
};

export const ALL_TFS: Timeframe[] = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"];

interface YahooConfig {
  interval: string;
  range: string;
  aggregateHours?: number;
}

const YAHOO_CONFIG: Record<Timeframe, YahooConfig> = {
  "1m": { interval: "1m", range: "5d" },
  "5m": { interval: "5m", range: "1mo" },
  "15m": { interval: "15m", range: "1mo" },
  "30m": { interval: "30m", range: "1mo" },
  "1h": { interval: "1h", range: "3mo" },
  "4h": { interval: "1h", range: "6mo", aggregateHours: 4 },
  "1d": { interval: "1d", range: "2y" },
  "1w": { interval: "1wk", range: "5y" },
};

const cache = new Map<string, { at: number; candles: Candle[] }>();
const TTL_FAST = 30_000; // تایم‌فریم‌های ۱ و ۵ دقیقه — تازگی سیگنال اسکالپ
const TTL_INTRADAY = 60_000;
const TTL_DAILY = 300_000;

export function getSymbolName(market: Market, symbol: string): string {
  const found = SYMBOLS[market].find((s) => s.symbol === symbol);
  return found ? found.name : symbol;
}

function cleanCandles(candles: Candle[], maxLen = 400): Candle[] {
  const filtered = candles.filter(
    (c) => isFinite(c.open) && isFinite(c.high) && isFinite(c.low) && isFinite(c.close) && c.high >= c.low
  );
  return filtered.slice(-maxLen);
}

async function fetchBinance(symbol: string, tf: Timeframe): Promise<Candle[]> {
  const interval = BINANCE_INTERVALS[tf];
  const url = `https://data-api.binance.vision/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${interval}&limit=500`;
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error(`Binance error ${res.status}`);
  const rows = (await res.json()) as unknown[][];
  return cleanCandles(
    rows.map((r) => ({
      time: Math.floor(Number(r[0]) / 1000),
      open: Number(r[1]),
      high: Number(r[2]),
      low: Number(r[3]),
      close: Number(r[4]),
      volume: Number(r[5]),
    }))
  );
}

function aggregateToHours(candles: Candle[], hours: number): Candle[] {
  const bucketMs = hours * 3600;
  const map = new Map<number, Candle>();
  for (const c of candles) {
    const bucket = Math.floor(c.time / bucketMs) * bucketMs;
    const existing = map.get(bucket);
    if (!existing) {
      map.set(bucket, { ...c, time: bucket });
    } else {
      existing.high = Math.max(existing.high, c.high);
      existing.low = Math.min(existing.low, c.low);
      existing.close = c.close;
      existing.volume += c.volume;
    }
  }
  return [...map.values()].sort((a, b) => a.time - b.time);
}

async function fetchYahoo(symbol: string, tf: Timeframe): Promise<Candle[]> {
  const cfg = YAHOO_CONFIG[tf];
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${cfg.interval}&range=${cfg.range}`;
  const res = await fetch(url, {
    cache: "no-store",
    headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
  });
  if (!res.ok) throw new Error(`Yahoo error ${res.status}`);
  const json = await res.json();
  const result = json?.chart?.result?.[0];
  if (!result?.timestamp) throw new Error("No Yahoo data");
  const q = result.indicators?.quote?.[0];
  if (!q) throw new Error("No Yahoo quote data");
  let candles: Candle[] = result.timestamp
    .map((t: number, i: number) => ({
      time: t,
      open: q.open?.[i],
      high: q.high?.[i],
      low: q.low?.[i],
      close: q.close?.[i],
      volume: q.volume?.[i] ?? 0,
    }))
    .filter((c: Candle) => c.open != null && c.close != null);
  if (cfg.aggregateHours) candles = aggregateToHours(candles, cfg.aggregateHours);
  return cleanCandles(candles);
}

export async function getCandles(market: Market, symbol: string, tf: Timeframe): Promise<Candle[]> {
  const key = `${market}:${symbol}:${tf}`;
  const cached = cache.get(key);
  const ttl = tf === "1d" || tf === "1w" ? TTL_DAILY : tf === "1m" || tf === "5m" ? TTL_FAST : TTL_INTRADAY;
  if (cached && Date.now() - cached.at < ttl) return cached.candles;

  let candles: Candle[];
  if (market === "crypto") {
    candles = await fetchBinance(symbol, tf);
  } else {
    candles = await fetchYahoo(symbol, tf);
  }
  if (candles.length < 60) throw new Error("دیتای کافی برای تحلیل این نماد موجود نیست (حداقل ۶۰ کندل).");
  cache.set(key, { at: Date.now(), candles });
  return candles;
}

export function buildQuote(candles: Candle[]) {
  const last = candles[candles.length - 1];
  const prev = candles.length > 1 ? candles[candles.length - 2] : last;
  const window = candles.slice(-40);
  return {
    last: last.close,
    changePct: prev.close > 0 ? ((last.close - prev.close) / prev.close) * 100 : 0,
    periodHigh: Math.max(...window.map((c) => c.high)),
    periodLow: Math.min(...window.map((c) => c.low)),
    volume: last.volume || 0,
  };
}
