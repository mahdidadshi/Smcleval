import type {
  Candle,
  FvgInfo,
  LiquidityPool,
  ObInfo,
  SessionInfo,
  SmcSnapshot,
  SweepEvent,
  Timeframe,
  TrapEvent,
  VolumeInfo,
} from "./types";

/* ------------------------------- ابزارهای پایه ------------------------------- */

export interface Swing {
  index: number;
  time: number;
  price: number;
  type: "high" | "low";
}

export function findSwings(candles: Candle[], left = 3, right = 3): Swing[] {
  const swings: Swing[] = [];
  for (let i = left; i < candles.length - right; i++) {
    let isHigh = true;
    let isLow = true;
    for (let j = i - left; j <= i + right; j++) {
      if (j === i) continue;
      if (candles[j].high >= candles[i].high) isHigh = false;
      if (candles[j].low <= candles[i].low) isLow = false;
      if (!isHigh && !isLow) break;
    }
    if (isHigh) swings.push({ index: i, time: candles[i].time, price: candles[i].high, type: "high" });
    if (isLow) swings.push({ index: i, time: candles[i].time, price: candles[i].low, type: "low" });
  }
  return swings;
}

export function avgRangeOf(candles: Candle[], n = 14): number {
  const w = candles.slice(-n);
  return w.reduce((s, c) => s + (c.high - c.low), 0) / Math.max(w.length, 1);
}

function avgBodyOf(candles: Candle[], n = 20): number {
  const w = candles.slice(-n);
  return w.reduce((s, c) => s + Math.abs(c.close - c.open), 0) / Math.max(w.length, 1);
}

/* ------------------------------ ساختار بازار ------------------------------ */

export interface StructureInfo {
  trend: "bullish" | "bearish" | "ranging";
  lastEvent: { type: "BOS" | "CHoCH"; dir: "bull" | "bear"; barsAgo: number } | null;
  recentSwings: Swing[];
  lastSwingHigh: number | null;
  lastSwingLow: number | null;
}

export function analyzeStructure(candles: Candle[], swings: Swing[]): StructureInfo {
  const n = candles.length;
  const start = Math.max(3, n - 140);
  const mySwings = swings.filter((s) => s.index >= start - 10).sort((a, b) => a.index - b.index);

  const hs = mySwings.filter((s) => s.type === "high");
  const ls = mySwings.filter((s) => s.type === "low");
  let trend: StructureInfo["trend"] = "ranging";
  if (hs.length >= 2 && ls.length >= 2) {
    const hh = hs[hs.length - 1].price > hs[hs.length - 2].price;
    const hl = ls[ls.length - 1].price > ls[ls.length - 2].price;
    if (hh && hl) trend = "bullish";
    else if (!hh && !hl) trend = "bearish";
  }

  let lastEvent: StructureInfo["lastEvent"] = null;
  let activeHigh: Swing | null = null;
  let activeLow: Swing | null = null;
  let curTrend: "bull" | "bear" | null = trend === "bullish" ? "bull" : trend === "bearish" ? "bear" : null;
  let si = 0;
  for (let i = start; i < n; i++) {
    while (si < mySwings.length && mySwings[si].index + 3 <= i) {
      const s = mySwings[si];
      if (s.type === "high") activeHigh = s;
      else activeLow = s;
      si++;
    }
    const c = candles[i];
    const prevClose = candles[i - 1].close;
    if (activeHigh && c.close > activeHigh.price && prevClose <= activeHigh.price) {
      lastEvent = { type: curTrend === "bear" ? "CHoCH" : "BOS", dir: "bull", barsAgo: n - 1 - i };
      curTrend = "bull";
      trend = "bullish";
      activeHigh = null;
    } else if (activeLow && c.close < activeLow.price && prevClose >= activeLow.price) {
      lastEvent = { type: curTrend === "bull" ? "CHoCH" : "BOS", dir: "bear", barsAgo: n - 1 - i };
      curTrend = "bear";
      trend = "bearish";
      activeLow = null;
    }
  }

  return {
    trend,
    lastEvent,
    recentSwings: mySwings.slice(-8),
    lastSwingHigh: hs.length ? hs[hs.length - 1].price : null,
    lastSwingLow: ls.length ? ls[ls.length - 1].price : null,
  };
}

/* ------------------------------ نقدینگی ------------------------------ */

export interface LiquidityInfo {
  pools: LiquidityPool[];
  unsweptAbove: LiquidityPool[];
  unsweptBelow: LiquidityPool[];
  sweeps: SweepEvent[];
  eqhCount: number;
  eqlCount: number;
}

export function analyzeLiquidity(candles: Candle[], swings: Swing[], avgRange: number): LiquidityInfo {
  const n = candles.length;
  const lastPrice = candles[n - 1].close;
  const tol = Math.max(avgRange * 0.22, lastPrice * 0.0006);
  const window = swings.filter((s) => s.index >= n - 170);

  const cluster = (list: Swing[]) => {
    const out: { price: number; touches: number; lastIndex: number }[] = [];
    for (const s of [...list].sort((a, b) => a.index - b.index)) {
      const f = out.find((o) => Math.abs(o.price - s.price) <= tol);
      if (f) {
        f.price = (f.price * f.touches + s.price) / (f.touches + 1);
        f.touches++;
        f.lastIndex = s.index;
      } else {
        out.push({ price: s.price, touches: 1, lastIndex: s.index });
      }
    }
    return out;
  };

  const eqh = cluster(window.filter((s) => s.type === "high"));
  const eql = cluster(window.filter((s) => s.type === "low"));

  const evaluate = (price: number, afterIndex: number, type: "high" | "low") => {
    for (let i = afterIndex + 1; i < n; i++) {
      const c = candles[i];
      if (type === "high" && c.high > price) return { i, trap: c.close < price };
      if (type === "low" && c.low < price) return { i, trap: c.close > price };
    }
    return null;
  };

  const pools: LiquidityPool[] = [];
  for (const p of eqh) {
    const ev = evaluate(p.price, p.lastIndex, "high");
    pools.push({
      price: p.price,
      side: "above",
      touches: p.touches,
      status: ev ? (ev.trap ? "swept" : "broken") : "unswept",
      eventBarsAgo: ev ? n - 1 - ev.i : n - 1 - p.lastIndex,
    });
  }
  for (const p of eql) {
    const ev = evaluate(p.price, p.lastIndex, "low");
    pools.push({
      price: p.price,
      side: "below",
      touches: p.touches,
      status: ev ? (ev.trap ? "swept" : "broken") : "unswept",
      eventBarsAgo: ev ? n - 1 - ev.i : n - 1 - p.lastIndex,
    });
  }

  const unsweptAbove = pools
    .filter((p) => p.side === "above" && p.status === "unswept")
    .sort((a, b) => Math.abs(a.price - lastPrice) - Math.abs(b.price - lastPrice));
  const unsweptBelow = pools
    .filter((p) => p.side === "below" && p.status === "unswept")
    .sort((a, b) => Math.abs(a.price - lastPrice) - Math.abs(b.price - lastPrice));

  const sweeps: SweepEvent[] = pools
    .filter((p) => p.status === "swept" && p.eventBarsAgo <= 12)
    .map((p) => ({
      dir: (p.side === "above" ? "bear" : "bull") as SweepEvent["dir"],
      barsAgo: p.eventBarsAgo,
      price: p.price,
      kind: p.touches >= 2 ? "شکار نقدینگی چندبرخوردی (EQ)" : "SFP / شکار استاپ",
    }))
    .sort((a, b) => a.barsAgo - b.barsAgo)
    .slice(0, 4);

  return {
    pools,
    unsweptAbove: unsweptAbove.slice(0, 5),
    unsweptBelow: unsweptBelow.slice(0, 5),
    sweeps,
    eqhCount: eqh.filter((p) => p.touches >= 2).length,
    eqlCount: eql.filter((p) => p.touches >= 2).length,
  };
}

/* ------------------------------ تله‌های روانی ------------------------------ */

export function analyzeTraps(candles: Candle[], liq: LiquidityInfo, avgRange: number): { traps: TrapEvent[]; roundLevel: number | null } {
  const n = candles.length;
  const lastPrice = candles[n - 1].close;
  const traps: TrapEvent[] = [];

  for (const s of liq.sweeps) {
    traps.push({
      name: s.dir === "bear" ? "تله صعودی / SFP سقف (شکار استاپ خریداران)" : "تله نزولی / SFP کف (شکار استاپ فروشندگان)",
      dir: s.dir,
      barsAgo: s.barsAgo,
    });
  }

  // فیک‌بریک‌اوت با کلوز: شکست سطح و بازگشت سریع
  for (const p of liq.pools) {
    if (p.status !== "broken" || p.eventBarsAgo > 10) continue;
    const evIndex = n - 1 - p.eventBarsAgo;
    for (let j = evIndex + 1; j <= Math.min(evIndex + 2, n - 1); j++) {
      const c = candles[j];
      if (p.side === "above" && c.close < p.price) {
        traps.push({ name: "تله صعودی (Bull Trap) — شکست کاذب سقف", dir: "bear", barsAgo: n - 1 - j });
        break;
      }
      if (p.side === "below" && c.close > p.price) {
        traps.push({ name: "تله نزولی (Bear Trap) — شکست کاذب کف", dir: "bull", barsAgo: n - 1 - j });
        break;
      }
    }
  }

  // سطح روانی (عدد رند)
  const pow = Math.pow(10, Math.floor(Math.log10(Math.max(lastPrice, 1e-9))));
  let step = pow / 10;
  if (lastPrice / step < 2.5) step = pow / 100;
  const nearest = Math.round(lastPrice / step) * step;
  const roundLevel = Math.abs(lastPrice - nearest) <= avgRange * 0.35 ? nearest : null;

  const seen = new Set<string>();
  return {
    traps: traps
      .sort((a, b) => a.barsAgo - b.barsAgo)
      .filter((t) => {
        if (seen.has(t.name)) return false;
        seen.add(t.name);
        return true;
      })
      .slice(0, 4),
    roundLevel,
  };
}

/* ------------------------------ سشن‌ها ------------------------------ */

export function analyzeSessions(candles: Candle[], tf: Timeframe): SessionInfo | null {
  if (tf !== "1m" && tf !== "5m" && tf !== "15m" && tf !== "30m" && tf !== "1h") return null;
  const n = candles.length;
  const hourUTC = (t: number) => new Date(t * 1000).getUTCHours();
  const dayStart = (t: number) => Math.floor(t / 86400) * 86400;

  // آخرین سشن آسیا: کندل‌های 00:00 تا 08:00 UTC
  let asian: Candle[] = [];
  for (let d = 0; d < 3; d++) {
    const anchor = dayStart(candles[n - 1].time) - d * 86400;
    const dc = candles.filter((c) => c.time >= anchor && c.time < anchor + 8 * 3600);
    if (dc.length >= 3) {
      asian = dc;
      break;
    }
  }
  if (asian.length < 3) return null;

  const asianHigh = Math.max(...asian.map((c) => c.high));
  const asianLow = Math.min(...asian.map((c) => c.low));
  const asianEnd = dayStart(asian[0].time) + 8 * 3600;

  const after = candles.filter((c) => c.time >= asianEnd);
  if (after.length < 2) return null;

  let sweepOfAsian: SessionInfo["sweepOfAsian"] = null;
  let breakout: SessionInfo["breakout"] = null;
  for (const c of after) {
    const barsAgo = n - 1 - candles.indexOf(c);
    if (c.high > asianHigh && c.close < asianHigh) sweepOfAsian = { dir: "bear", barsAgo };
    else if (c.low < asianLow && c.close > asianLow) sweepOfAsian = { dir: "bull", barsAgo };
    else if (c.close > asianHigh) breakout = "above";
    else if (c.close < asianLow) breakout = "below";
  }

  const lastHour = hourUTC(candles[n - 1].time);
  const sessionName = lastHour < 8 ? "آسیا" : lastHour < 13 ? "لندن" : lastHour < 21 ? "لندن / نیویورک" : "بعد از نیویورک";
  const killzone = (lastHour >= 7 && lastHour < 10) || (lastHour >= 12 && lastHour < 15);

  return { sessionName, killzone, asianHigh, asianLow, sweepOfAsian, breakout };
}

/* ------------------------------ والیوم تریدینگ ------------------------------ */

export function analyzeVolume(candles: Candle[]): VolumeInfo {
  const n = candles.length;
  const window = candles.slice(-150);
  const min = Math.min(...window.map((c) => c.low));
  const max = Math.max(...window.map((c) => c.high));
  const bins = 24;
  const vols = new Array(bins).fill(0);
  for (const c of window) {
    const mid = (c.high + c.low) / 2;
    let bi = Math.floor(((mid - min) / Math.max(max - min, 1e-12)) * bins);
    bi = Math.min(bins - 1, Math.max(0, bi));
    vols[bi] += c.volume || 0;
  }
  const maxVol = Math.max(...vols, 1e-12);
  const pocIdx = vols.indexOf(maxVol);
  const priceOfBin = (b: number) => min + ((b + 0.5) / bins) * Math.max(max - min, 1e-12);
  const poc = priceOfBin(pocIdx);
  const hvn: number[] = [];
  const lvn: number[] = [];
  for (let b = 0; b < bins; b++) {
    if (vols[b] >= 0.65 * maxVol && Math.abs(b - pocIdx) > 1) hvn.push(priceOfBin(b));
    else if (vols[b] <= 0.18 * maxVol) lvn.push(priceOfBin(b));
  }
  const priceVsPoc = candles[n - 1].close >= poc ? "above" : "below";

  let dSum = 0;
  let vSum = 0;
  for (const c of candles.slice(-10)) {
    const r = Math.max(c.high - c.low, 1e-12);
    dSum += ((c.close - c.open) / r) * (c.volume || 0);
    vSum += c.volume || 0;
  }
  const delta10 = vSum > 0 ? Math.max(-100, Math.min(100, (dSum / vSum) * 100)) : 0;

  const avg20 =
    candles.slice(-21, -1).reduce((s, c) => s + (c.volume || 0), 0) / Math.max(Math.min(20, n - 1), 1);
  const volumeRatio = avg20 > 0 ? (candles[n - 1].volume || 0) / avg20 : 1;

  let climax: VolumeInfo["climax"] = null;
  let absorption: VolumeInfo["absorption"] = null;
  const trend10 = candles[n - 1].close - candles[Math.max(n - 11, 0)].close;
  for (let i = Math.max(1, n - 6); i < n && (!climax || !absorption); i++) {
    const c = candles[i];
    const r = Math.max(c.high - c.low, 1e-12);
    const vol = c.volume || 0;
    const body = Math.abs(c.close - c.open);
    const upperW = c.high - Math.max(c.open, c.close);
    const lowerW = Math.min(c.open, c.close) - c.low;
    if (avg20 > 0 && vol > 2.3 * avg20) {
      if (!climax && lowerW > body * 1.5 && lowerW > upperW * 1.2) climax = { dir: "bull", barsAgo: n - 1 - i };
      else if (!climax && upperW > body * 1.5 && upperW > lowerW * 1.2) climax = { dir: "bear", barsAgo: n - 1 - i };
      else if (!absorption && body < r * 0.3 && body > 0) absorption = { dir: trend10 >= 0 ? "bear" : "bull", barsAgo: n - 1 - i };
    }
  }

  return { poc, hvn: hvn.slice(0, 4), lvn: lvn.slice(0, 4), priceVsPoc, delta10, volumeRatio, climax, absorption };
}

/* --------------------------- اردربلاک و FVG --------------------------- */

export function analyzeOB_FVG(candles: Candle[], avgBody: number): { obs: ObInfo[]; fvgs: FvgInfo[] } {
  const n = candles.length;
  const obs: ObInfo[] = [];
  const fvgs: FvgInfo[] = [];
  const start = Math.max(2, n - 90);

  for (let i = start; i < n - 1; i++) {
    const c = candles[i];
    const nx = candles[i + 1];
    const body = Math.abs(nx.close - nx.open);
    if (body >= avgBody * 1.4) {
      if (c.close < c.open && nx.close > nx.open && nx.close > c.high) {
        let mitigated = false;
        for (let j = i + 2; j < n; j++) if (candles[j].low <= c.high) { mitigated = true; break; }
        obs.push({ type: "bull", top: c.high, bottom: c.low, barsAgo: n - 1 - i, mitigated });
      }
      if (c.close > c.open && nx.close < nx.open && nx.close < c.low) {
        let mitigated = false;
        for (let j = i + 2; j < n; j++) if (candles[j].high >= c.low) { mitigated = true; break; }
        obs.push({ type: "bear", top: c.high, bottom: c.low, barsAgo: n - 1 - i, mitigated });
      }
    }
    const a = candles[i - 2];
    if (c.low > a.high) {
      let filled = false;
      for (let j = i + 1; j < n; j++) if (candles[j].low <= a.high) { filled = true; break; }
      fvgs.push({ type: "bull", top: c.low, bottom: a.high, barsAgo: n - 1 - i, filled });
    }
    if (c.high < a.low) {
      let filled = false;
      for (let j = i + 1; j < n; j++) if (candles[j].high >= a.low) { filled = true; break; }
      fvgs.push({ type: "bear", top: a.low, bottom: c.high, barsAgo: n - 1 - i, filled });
    }
  }
  return { obs, fvgs };
}

/* ------------------------------ چرخه بازار (Wyckoff) ------------------------------ */

export function analyzeCycle(candles: Candle[], trend: string, avgRange: number): string {
  const n = candles.length;
  const basis = candles.slice(-50, -8);
  if (basis.length < 20) return trend === "bullish" ? "مارکاپ (ادامه روند صعودی)" : trend === "bearish" ? "مارک‌داون (ادامه روند نزولی)" : "نامشخص";
  const rHi = Math.max(...basis.map((c) => c.high));
  const rLo = Math.min(...basis.map((c) => c.low));
  const rW = rHi - rLo;
  if (rW < avgRange * 6.5) {
    const tail = candles.slice(-8);
    const sweptLow = tail.some((c) => c.low < rLo && c.close > rLo);
    const sweptHigh = tail.some((c) => c.high > rHi && c.close < rHi);
    const brokeUp = tail.some((c) => c.close > rHi + avgRange * 0.15);
    const brokeDown = tail.some((c) => c.close < rLo - avgRange * 0.15);
    if (sweptLow) return "فنر (Spring) — فاز C انباشت؛ احتمال شروع موج صعودی";
    if (sweptHigh) return "آپثراست (Upthrust) — فاز توزیع؛ احتمال شروع موج نزولی";
    if (brokeUp) return "شروع مارکاپ — خروج موفق از انباشت";
    if (brokeDown) return "شروع مارک‌داون — خروج از توزیع";
    const mid = (rHi + rLo) / 2;
    return candles[n - 1].close > mid ? "توزیع در سقف رنج (احتیاط برای خرید)" : "انباشت در کف رنج (صبر برای فنر)";
  }
  return trend === "bullish" ? "مارکاپ (روند صعودی جاری)" : trend === "bearish" ? "مارک‌داون (روند نزولی جاری)" : "نامشخص";
}

/* ------------------------------ باندل کامل SMC ------------------------------ */

export interface SmcBundle {
  snapshot: SmcSnapshot;
  structure: StructureInfo;
  liquidity: LiquidityInfo;
}

export function analyzeSmc(candles: Candle[], tf: Timeframe): SmcBundle {
  const n = candles.length;
  const lastPrice = candles[n - 1].close;
  const swings = findSwings(candles, 3, 3);
  const avgRange = avgRangeOf(candles, 14);
  const structure = analyzeStructure(candles, swings);
  const liquidity = analyzeLiquidity(candles, swings, avgRange);
  const { traps, roundLevel } = analyzeTraps(candles, liquidity, avgRange);
  const sessions = analyzeSessions(candles, tf);
  const volume = analyzeVolume(candles);
  const { obs, fvgs } = analyzeOB_FVG(candles, avgBodyOf(candles, 20));

  // پرمیوم / دیسکانت از سوینگ‌های مهم ۱۴۰ کندل اخیر
  const win = candles.slice(-140);
  const hi = Math.max(...win.map((c) => c.high));
  const lo = Math.min(...win.map((c) => c.low));
  const eq = (hi + lo) / 2;
  const band = (hi - lo) * 0.04;
  const zone: "premium" | "discount" | "equilibrium" =
    lastPrice > eq + band ? "premium" : lastPrice < eq - band ? "discount" : "equilibrium";

  return {
    snapshot: {
      trend: structure.trend,
      lastEvent: structure.lastEvent,
      lastSwingHigh: structure.lastSwingHigh,
      lastSwingLow: structure.lastSwingLow,
      avgRange,
      poolsAbove: liquidity.unsweptAbove,
      poolsBelow: liquidity.unsweptBelow,
      recentSweeps: liquidity.sweeps,
      traps,
      roundLevel,
      sessions,
      volume,
      obs: obs.filter((o) => !o.mitigated && o.barsAgo < 80).slice(0, 6),
      fvgs: fvgs.filter((f) => !f.filled && f.barsAgo < 80).slice(0, 6),
      premiumDiscount: { eq, zone },
      cyclePhase: analyzeCycle(candles, structure.trend, avgRange),
    },
    structure,
    liquidity,
  };
}
