import { PrismaClient } from '@prisma/client'
import { PrismaLibSql } from '@prisma/adapter-libsql'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// اگر DATABASE_URL با libsql:// شروع شود (مثل Turso) از آداپتور LibSQL استفاده می‌شود؛
// در غیر این صورت SQLite فایل محلی (پیش‌فرض: file:./dev.db)
function makeDb(): PrismaClient {
  const url = process.env.DATABASE_URL || 'file:./dev.db'
  if (url.startsWith('libsql://')) {
    const adapter = new PrismaLibSql({
      url,
      authToken: process.env.DATABASE_AUTH_TOKEN,
    })
    return new PrismaClient({ adapter })
  }
  return new PrismaClient({ log: ['query'] })
}

export const db =
  globalForPrisma.prisma ?? makeDb()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
