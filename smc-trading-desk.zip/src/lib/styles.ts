import type { Signal, SmcSnapshot, StyleResult } from "./types";

export function scoreToSignal(score: number): Signal {
  if (score >= 60) return "strong_buy";
  if (score >= 25) return "buy";
  if (score <= -60) return "strong_sell";
  if (score <= -25) return "sell";
  return "neutral";
}

const clamp = (v: number) => Math.max(-100, Math.min(100, v));

/* ---------------- ۱. ساختار بازار (Market Structure) ---------------- */
export function styleStructure(s: SmcSnapshot): StyleResult {
  const reasons: string[] = [];
  let score = 0;

  if (s.trend === "bullish") {
    score += 40;
    reasons.push("ساختار سقف و کف‌های بالاتر (HH/HL) — روند ساختاری صعودی است.");
  } else if (s.trend === "bearish") {
    score -= 40;
    reasons.push("ساختار سقف و کف‌های پایین‌تر (LH/LL) — روند ساختاری نزولی است.");
  } else {
    reasons.push("ساختار بازار رنج است؛ سقف و کف‌ها فاقد برتری جهت‌دار هستند.");
  }

  if (s.lastEvent) {
    const fa = s.lastEvent.dir === "bull" ? "صعودی" : "نزولی";
    if (s.lastEvent.type === "CHoCH") {
      score += s.lastEvent.dir === "bull" ? 30 : -30;
      reasons.push(`CHoCH ${fa} در ${s.lastEvent.barsAgo} کندل قبل — تغییر کاراکتر بازار و احتمال شروع روند جدید.`);
    } else {
      score += s.lastEvent.dir === "bull" ? 20 : -20;
      reasons.push(`BOS ${fa} در ${s.lastEvent.barsAgo} کندل قبل — ادامه روند پس از شکست ساختار.`);
    }
  }

  return { id: "structure", name: "ساختار بازار (BOS / CHoCH)", weight: 0.18, score: clamp(score), signal: scoreToSignal(clamp(score)), reasons };
}

/* ---------------- ۲. نقدینگی و شکار استاپ ---------------- */
export function styleLiquidity(s: SmcSnapshot): StyleResult {
  const reasons: string[] = [];
  let score = 0;

  for (const sw of s.recentSweeps.slice(0, 2)) {
    if (sw.dir === "bull") {
      score += 40;
      reasons.push(`نقدینگی زیر کف ${sw.price.toPrecision(6)} شکار شد (${sw.kind}) — ${sw.barsAgo} کندل قبل؛ سوخت حرکت صعودی تأمین شد.`);
    } else {
      score -= 40;
      reasons.push(`نقدینگی بالای سقف ${sw.price.toPrecision(6)} شکار شد (${sw.kind}) — ${sw.barsAgo} کندل قبل؛ سیگنال برگشت نزولی.`);
    }
  }

  if (s.poolsAbove.length > 0 && s.poolsAbove.length > s.poolsBelow.length) {
    score += 8;
    reasons.push(`${s.poolsAbove.length} استخر نقدینگی نشکسته بالای قیمت وجود دارد — مگنتیت صعودی.`);
  } else if (s.poolsBelow.length > 0 && s.poolsBelow.length > s.poolsAbove.length) {
    score -= 8;
    reasons.push(`${s.poolsBelow.length} استخر نقدینگی نشکسته زیر قیمت وجود دارد — جاذبه نزولی.`);
  }

  if (s.poolsAbove.length === 0 && s.poolsBelow.length === 0) {
    reasons.push("نقدینگی واضحی (سقف/کف نشکسته) در محدوده دید وجود ندارد.");
  }

  return { id: "liquidity", name: "نقدینگی و شکار استاپ (Liquidity)", weight: 0.18, score: clamp(score), signal: scoreToSignal(clamp(score)), reasons };
}

/* ---------------- ۳. تله‌های روانی ---------------- */
export function styleTraps(s: SmcSnapshot): StyleResult {
  const reasons: string[] = [];
  let score = 0;

  if (s.traps.length === 0) {
    reasons.push("تله یا فیک‌بریک‌اوت فعالی در ۱۲ کندل اخیر شناسایی نشد؛ رفتار قیمت طبیعی است.");
    return { id: "traps", name: "تله‌های روانی (Traps & SFP)", weight: 0.15, score: 0, signal: "neutral", reasons };
  }

  for (const t of s.traps.slice(0, 3)) {
    if (t.dir === "bull") {
      score += 35;
      reasons.push(`${t.name} — ${t.barsAgo} کندل قبل؛ خریداران نهادی احتمالاً وارد شده‌اند.`);
    } else {
      score -= 35;
      reasons.push(`${t.name} — ${t.barsAgo} کندل قبل؛ فشار فروش نهادی محتمل است.`);
    }
  }

  if (s.roundLevel != null) {
    reasons.push(`قیمت نزدیک سطح روانی عدد رند ${s.roundLevel.toPrecision(6)} است؛ واکنش‌های کاذب به این سطح رایج است.`);
  }

  return { id: "traps", name: "تله‌های روانی (Traps & SFP)", weight: 0.15, score: clamp(score), signal: scoreToSignal(clamp(score)), reasons };
}

/* ---------------- ۴. استراتژی سشن‌ها ---------------- */
export function styleSessions(s: SmcSnapshot): StyleResult {
  const reasons: string[] = [];
  let score = 0;
  const ses = s.sessions;

  if (!ses) {
    return {
      id: "sessions",
      name: "استراتژی سشن‌ها (Asia/London/NY)",
      weight: 0.1,
      score: 0,
      signal: "neutral",
      reasons: ["این تایم‌فریم یا نماد برای تحلیل سشن‌ها مناسب نیست (سشن‌ها فقط روی ۱۵ دقیقه و ۱ ساعت معنا دارند)."],
    };
  }

  reasons.push(`سشن جاری: ${ses.sessionName}${ses.killzone ? " — داخل کیل‌زون (بالاترین احتمال حرکت واقعی)" : ""}.`);
  if (ses.asianHigh != null && ses.asianLow != null) {
    reasons.push(`رنج سشن آسیا: ${ses.asianLow.toPrecision(6)} تا ${ses.asianHigh.toPrecision(6)}.`);
  }

  if (ses.sweepOfAsian) {
    if (ses.sweepOfAsian.dir === "bull") {
      score += 40;
      reasons.push(`کف رنج آسیا شکار شد و قیمت برگشت (${ses.sweepOfAsian.barsAgo} کندل قبل) — الگوی کلاسیک جوداس سوینگ؛ احتمال حرکت صعودی در سشن لندن/نیویورک.`);
    } else {
      score -= 40;
      reasons.push(`سقف رنج آسیا شکار شد و قیمت برگشت (${ses.sweepOfAsian.barsAgo} کندل قبل) — شکار خریداران دیرکند؛ چشم‌انداز نزولی.`);
    }
  } else if (ses.breakout === "above") {
    score += 15;
    reasons.push("قیمت بالای رنج آسیا تثبیت شده؛ سناریوی ادامه‌دار صعودی سشن.");
  } else if (ses.breakout === "below") {
    score -= 15;
    reasons.push("قیمت زیر رنج آسیا تثبیت شده؛ سناریوی ادامه‌دار نزولی سشن.");
  } else {
    reasons.push("قیمت داخل رنج آسیا در حال نوسان است؛ بازار در فاز انتظار.");
  }

  return { id: "sessions", name: "استراتژی سشن‌ها (Asia/London/NY)", weight: 0.1, score: clamp(score), signal: scoreToSignal(clamp(score)), reasons };
}

/* ---------------- ۵. والیوم تریدینگ ---------------- */
export function styleVolume(s: SmcSnapshot): StyleResult {
  const reasons: string[] = [];
  let score = 0;
  const v = s.volume;

  if (v.priceVsPoc === "above") {
    score += 20;
    reasons.push(`قیمت بالای POC پروفایل والیوم (${v.poc.toPrecision(6)}) است؛ پذیرش قیمت در ناحیه بالای ارزش.`);
  } else {
    score -= 20;
    reasons.push(`قیمت زیر POC پروفایل والیوم (${v.poc.toPrecision(6)}) است؛ بازار در ناحیه تخفیف ارزش معامله می‌شود.`);
  }

  if (v.delta10 > 15) {
    score += 25;
    reasons.push(`دلتای والیوم ۱۰ کندل اخیر مثبت و قوی (${v.delta10.toFixed(0)}+) — فشار خرید واقعی در سفارشات.`);
  } else if (v.delta10 < -15) {
    score -= 25;
    reasons.push(`دلتای والیوم ۱۰ کندل اخیر منفی و قوی (${v.delta10.toFixed(0)}) — فشار فروش غالب است.`);
  } else {
    reasons.push(`دلتای والیوم (${v.delta10.toFixed(0)}) تعادل نسبی بین خریدار و فروشنده نشان می‌دهد.`);
  }

  if (v.volumeRatio > 1.8) {
    reasons.push(`حجم کندل آخر ${v.volumeRatio.toFixed(1)} برابر میانگین است — رخداد والیوم‌ای مهم در جریان است.`);
  }

  if (v.climax) {
    if (v.climax.dir === "bull") {
      score += 20;
      reasons.push(`کلایمکس فروش با والیوم بالا و سایه بلند پایین (${v.climax.barsAgo} کندل قبل) — نشانه خستگی فروشندگان (Wyckoff Selling Climax).`);
    } else {
      score -= 20;
      reasons.push(`کلایمکس خرید با سایه بلند بالا (${v.climax.barsAgo} کندل قبل) — خستگی خریداران و احتمال اصلاح.`);
    }
  }
  if (v.absorption) {
    score += v.absorption.dir === "bull" ? 12 : -12;
    reasons.push(
      `جذب سفارش (Absorption) ${v.absorption.dir === "bull" ? "صعودی" : "نزولی"} شناسایی شد — والیوم بالا بدون پیشرفت قیمت یعنی ${v.absorption.dir === "bull" ? "خریدار بزرگ در حال جمع‌آوری است" : "فروشنده بزرگ در حال تخلیه است"}.`
    );
  }

  return { id: "volume", name: "والیوم تریدینگ (Profile / Delta)", weight: 0.17, score: clamp(score), signal: scoreToSignal(clamp(score)), reasons };
}

/* ---------------- ۶. اردربلاک و FVG (سبک ICT) ---------------- */
export function styleOB_FVG(s: SmcSnapshot): StyleResult {
  const reasons: string[] = [];
  let score = 0;
  const lastPrice = s.volume.poc; // placeholder not used

  void lastPrice;
  const pd = s.premiumDiscount;
  if (pd.zone === "discount") {
    score += 20;
    reasons.push(`قیمت در دیسکانت رنج است (تعادل: ${pd.eq.toPrecision(6)}) — ناحیه ترجیحی خریداران نهادی.`);
  } else if (pd.zone === "premium") {
    score -= 20;
    reasons.push(`قیمت در پرمیوم رنج است (تعادل: ${pd.eq.toPrecision(6)}) — ناحیه فروش نهادی و ریسک خرید بالا.`);
  } else {
    reasons.push(`قیمت حول تعادل رنج (${pd.eq.toPrecision(6)}) است؛ هنوز در ناحیه پرمیوم/دیسکانت قرار ندارد.`);
  }

  const bullOB = s.obs.filter((o) => o.type === "bull");
  const bearOB = s.obs.filter((o) => o.type === "bear");
  if (bullOB.length > 0) {
    score += 18;
    reasons.push(`${bullOB.length} اردربلاک صعودی نشکسته زیر قیمت وجود دارد (نزدیک‌ترین: ${bullOB[0].bottom.toPrecision(6)} تا ${bullOB[0].top.toPrecision(6)}) — حمایت نهادی.`);
  }
  if (bearOB.length > 0) {
    score -= 18;
    reasons.push(`${bearOB.length} اردربلاک نزولی نشکسته بالای قیمت وجود دارد (نزدیک‌ترین: ${bearOB[0].bottom.toPrecision(6)} تا ${bearOB[0].top.toPrecision(6)}) — عرضه نهادی.`);
  }
  if (bullOB.length === 0 && bearOB.length === 0) {
    reasons.push("اردربلاک واضحی در ۹۰ کندل اخیر یافت نشد.");
  }

  const bullFVG = s.fvgs.filter((f) => f.type === "bull");
  const bearFVG = s.fvgs.filter((f) => f.type === "bear");
  if (bullFVG.length > 0) {
    score += 12;
    reasons.push(`شکاف نقدینگی صعودی (FVG) نشکسته در ${bullFVG[0].bottom.toPrecision(6)} تا ${bullFVG[0].top.toPrecision(6)} — ناحیه جذب اصلاح و ادامه صعود.`);
  }
  if (bearFVG.length > 0) {
    score -= 12;
    reasons.push(`شکاف نقدینگی نزولی (FVG) نشکسته در ${bearFVG[0].bottom.toPrecision(6)} تا ${bearFVG[0].top.toPrecision(6)} — سقف مقاومتی imbalance.`);
  }

  return { id: "obfvg", name: "اردربلاک و FVG (سبک ICT)", weight: 0.12, score: clamp(score), signal: scoreToSignal(clamp(score)), reasons };
}

/* ---------------- ۷. چرخه بازار (Wyckoff) ---------------- */
export function styleCycle(s: SmcSnapshot): StyleResult {
  const reasons: string[] = [];
  let score = 0;
  const phase = s.cyclePhase;

  reasons.push(`فاز چرخه: ${phase}.`);

  if (phase.includes("Spring") || phase.includes("انباشت در کف")) {
    score += 35;
    if (phase.includes("Spring")) reasons.push("فنر کلاسیک Wyckoff — شکار نقدینگی کف رنج و بازگشت سریع؛ سناریوی طلایی خرید.");
  } else if (phase.includes("Upthrust") || phase.includes("توزیع در سقف")) {
    score -= 35;
    if (phase.includes("Upthrust")) reasons.push("آپثراست کلاسیک — شکار سقف رنج و بازگشت؛ فرصت فروش با ریسک محدود بالای فنر.");
  } else if (phase.includes("شروع مارکاپ") || phase.includes("مارکاپ")) {
    score += 25;
  } else if (phase.includes("شروع مارک‌داون") || phase.includes("مارک‌داون")) {
    score -= 25;
  }

  return { id: "cycle", name: "چرخه بازار (Wyckoff)", weight: 0.1, score: clamp(score), signal: scoreToSignal(clamp(score)), reasons };
}

export function runAllStyles(s: SmcSnapshot): StyleResult[] {
  return [
    styleStructure(s),
    styleLiquidity(s),
    styleTraps(s),
    styleSessions(s),
    styleVolume(s),
    styleOB_FVG(s),
    styleCycle(s),
  ];
}

export function aggregateScore(styles: StyleResult[]): number {
  const totalWeight = styles.reduce((acc, st) => acc + st.weight, 0);
  return styles.reduce((acc, st) => acc + st.score * st.weight, 0) / totalWeight;
}
