"use client";

import { useCallback, useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { BookOpenText, Trophy, Activity, Percent, Coins, Trash2, Loader2, RotateCcw } from "lucide-react";
import { fmtPrice as fmt } from "./AnalysisPanel";

interface JournalEntry {
  id: number;
  createdAt: string;
  symbol: string;
  symbolName: string;
  market: string;
  timeframe: string;
  direction: "long" | "short" | "neutral";
  entryMin: number;
  entryMax: number;
  stopLoss: number;
  targets: number[];
  confidence: number;
  riskReward: number;
  summary: string;
  note: string | null;
  status: "open" | "win" | "loss" | "breakeven" | "cancelled";
  resultR: number | null;
  closedAt: string | null;
}

interface JournalStats {
  total: number;
  open: number;
  closed: number;
  wins: number;
  losses: number;
  breakevens: number;
  winRate: number;
  totalR: number;
  avgPlannedRr: number;
}

const STATUS_FA: Record<JournalEntry["status"], string> = {
  open: "باز",
  win: "سود",
  loss: "ضرر",
  breakeven: "سر به سر",
  cancelled: "لغو",
};

const STATUS_STYLE: Record<JournalEntry["status"], string> = {
  open: "border-amber-500/40 bg-amber-500/10 text-amber-300",
  win: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
  loss: "border-red-500/40 bg-red-500/10 text-red-300",
  breakeven: "border-zinc-500/40 bg-zinc-500/10 text-zinc-300",
  cancelled: "border-zinc-600/40 bg-zinc-600/10 text-zinc-400",
};

const DIRECTION_FA: Record<JournalEntry["direction"], string> = {
  long: "خرید",
  short: "فروش",
  neutral: "خنثی",
};

interface Props {
  refreshKey: number;
  currentPrice?: number;
  currentSymbol?: string;
}

export default function TradeJournal({ refreshKey, currentPrice, currentSymbol }: Props) {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [stats, setStats] = useState<JournalStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<number | null>(null);
  const { toast } = useToast();

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/journal", { cache: "no-store" });
      if (!res.ok) throw new Error("خطا در دریافت ژورنال");
      const j = await res.json();
      setEntries(j.entries ?? []);
      setStats(j.stats ?? null);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load, refreshKey]);

  async function patchEntry(id: number, data: { status?: string; resultR?: number | null }) {
    setBusyId(id);
    try {
      const res = await fetch("/api/journal", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, ...data }),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || "خطا در به‌روزرسانی");
      }
      await load();
    } catch (e) {
      toast({ title: "به‌روزرسانی ناموفق بود", description: e instanceof Error ? e.message : "خطای نامشخص", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  }

  async function removeEntry(id: number) {
    setBusyId(id);
    try {
      const res = await fetch(`/api/journal?id=${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("خطا در حذف");
      toast({ title: "پلن از ژورنال حذف شد" });
      await load();
    } catch (e) {
      toast({ title: "حذف ناموفق بود", description: e instanceof Error ? e.message : "خطای نامشخص", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  }

  /** پیشنهاد خودکار R هنگام بستن معامله — اگر قیمت لحظه‌ای همان نماد موجود باشد */
  function suggestR(e: JournalEntry, status: "win" | "loss" | "breakeven"): number | null {
    if (status === "loss") return -1;
    if (status === "breakeven") return 0;
    const entryMid = (e.entryMin + e.entryMax) / 2;
    const risk = Math.abs(entryMid - e.stopLoss);
    if (risk <= 0) return e.riskReward > 0 ? e.riskReward : 1;
    if (currentSymbol === e.symbol && currentPrice && isFinite(currentPrice)) {
      const moved = e.direction === "short" ? entryMid - currentPrice : currentPrice - entryMid;
      const r = moved / risk;
      if (r > 0.05) return Number(r.toFixed(2));
    }
    return e.riskReward > 0 ? e.riskReward : 1;
  }

  function handleStatusChange(e: JournalEntry, status: JournalEntry["status"]) {
    if (status === "open") {
      patchEntry(e.id, { status: "open", resultR: null });
      return;
    }
    const suggested = e.resultR ?? (status === "cancelled" ? null : suggestR(e, status));
    patchEntry(e.id, { status, resultR: suggested });
  }

  function handleREdit(e: JournalEntry, value: string) {
    const n = Number(value);
    patchEntry(e.id, { resultR: value === "" ? null : isFinite(n) ? n : null });
  }

  return (
    <Card className="border-zinc-800 bg-zinc-900/60">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm">
          <BookOpenText className="h-4 w-4 text-amber-400" />
          ژورنال معاملات و آمار عملکرد
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {stats && (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <div className="rounded-md border border-zinc-800 bg-zinc-800/40 p-2.5">
              <p className="mb-1 flex items-center gap-1 text-[10px] text-zinc-500">
                <Activity className="h-3 w-3" /> پلن‌ها
              </p>
              <p className="font-mono text-sm font-extrabold text-zinc-100">
                {stats.total} <span className="text-[10px] font-normal text-amber-400">({stats.open} باز)</span>
              </p>
            </div>
            <div className="rounded-md border border-zinc-800 bg-zinc-800/40 p-2.5">
              <p className="mb-1 flex items-center gap-1 text-[10px] text-zinc-500">
                <Percent className="h-3 w-3" /> نرخ برد
              </p>
              <p className={`font-mono text-sm font-extrabold ${stats.winRate >= 50 ? "text-emerald-400" : stats.closed > 0 ? "text-red-400" : "text-zinc-400"}`}>
                {stats.closed > 0 ? `${stats.winRate}٪` : "—"}
              </p>
              <p className="text-[10px] text-zinc-600">{stats.wins} برد / {stats.losses} باخت</p>
            </div>
            <div className="rounded-md border border-zinc-800 bg-zinc-800/40 p-2.5">
              <p className="mb-1 flex items-center gap-1 text-[10px] text-zinc-500">
                <Trophy className="h-3 w-3" /> مجموع R
              </p>
              <p className={`font-mono text-sm font-extrabold ${stats.totalR > 0 ? "text-emerald-400" : stats.totalR < 0 ? "text-red-400" : "text-zinc-400"}`} dir="ltr">
                {stats.totalR >= 0 ? "+" : ""}{stats.totalR}R
              </p>
            </div>
            <div className="rounded-md border border-zinc-800 bg-zinc-800/40 p-2.5">
              <p className="mb-1 flex items-center gap-1 text-[10px] text-zinc-500">
                <Coins className="h-3 w-3" /> میانگین RR پلن
              </p>
              <p className="font-mono text-sm font-extrabold text-zinc-100" dir="ltr">
                {stats.avgPlannedRr > 0 ? `1:${stats.avgPlannedRr}` : "—"}
              </p>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center gap-2 py-8 text-xs text-zinc-500">
            <Loader2 className="h-4 w-4 animate-spin" /> در حال بارگذاری ژورنال...
          </div>
        ) : entries.length === 0 ? (
          <p className="rounded-md border border-zinc-700/60 bg-zinc-800/40 px-3 py-6 text-center text-xs leading-5 text-zinc-500">
            هنوز پلنی ذخیره نشده است. از دکمه «ذخیره در ژورنال» روی کارت پلن معاملاتی، ستاپ‌های خود را ثبت کنید تا بعداً نتیجه‌شان را ثبت و عملکرد کلی‌تان را ببینید.
          </p>
        ) : (
          <ul className="max-h-[420px] space-y-2 overflow-y-auto pe-1 journal-scroll">
            {entries.map((e) => (
              <li key={e.id} className="rounded-lg border border-zinc-800 bg-zinc-900/70 p-3">
                <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-extrabold text-zinc-100">{e.symbolName}</span>
                    <span className="font-mono text-[10px] text-zinc-500" dir="ltr">{e.symbol} · {e.timeframe}</span>
                    <Badge variant="outline" className={`px-1.5 py-0 text-[10px] ${e.direction === "long" ? "border-emerald-500/40 text-emerald-300" : e.direction === "short" ? "border-red-500/40 text-red-300" : "border-zinc-600 text-zinc-400"}`}>
                      {DIRECTION_FA[e.direction]}
                    </Badge>
                    <Badge variant="outline" className={`px-1.5 py-0 text-[10px] ${STATUS_STYLE[e.status]}`}>
                      {STATUS_FA[e.status]}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Select value={e.status} onValueChange={(v) => handleStatusChange(e, v as JournalEntry["status"])}>
                      <SelectTrigger className="h-7 w-[92px] border-zinc-800 bg-zinc-900 px-2 text-[11px]" aria-label="وضعیت معامله">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="border-zinc-800 bg-zinc-900 text-xs">
                        {(Object.keys(STATUS_FA) as JournalEntry["status"][]).map((s) => (
                          <SelectItem key={s} value={s} className="text-xs">
                            {STATUS_FA[s]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {e.status === "open" ? (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 gap-1 border-emerald-500/30 bg-emerald-500/5 px-2 text-[11px] text-emerald-300 hover:bg-emerald-500/15"
                        disabled={busyId === e.id}
                        onClick={() => handleStatusChange(e, "win")}
                        title="ثبت نتیجه سودده (پیشنهاد R بر اساس قیمت لحظه‌ای همان نماد)"
                      >
                        <RotateCcw className="h-3 w-3" /> بستن
                      </Button>
                    ) : null}
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 text-zinc-600 hover:bg-red-500/10 hover:text-red-400"
                      disabled={busyId === e.id}
                      onClick={() => removeEntry(e.id)}
                      aria-label={`حذف پلن ${e.symbolName}`}
                    >
                      {busyId === e.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                    </Button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-zinc-400" dir="ltr">
                  <span>
                    ورود: <span className="font-mono font-bold text-zinc-200">{fmt(e.entryMin)}–{fmt(e.entryMax)}</span>
                  </span>
                  <span>
                    SL: <span className="font-mono font-bold text-red-300">{fmt(e.stopLoss)}</span>
                  </span>
                  {e.targets.slice(0, 3).map((t, i) => (
                    <span key={i}>
                      TP{i + 1}: <span className="font-mono font-bold text-emerald-300">{fmt(t)}</span>
                    </span>
                  ))}
                  <span className="ms-auto font-mono text-zinc-500">RR 1:{e.riskReward.toFixed(2)}</span>
                </div>

                {(e.status === "win" || e.status === "loss" || e.status === "breakeven") && (
                  <div className="mt-2 flex items-center gap-2">
                    <label className="text-[11px] text-zinc-500">نتیجه (بر حسب R):</label>
                    <Input
                      type="number"
                      step="0.1"
                      defaultValue={e.resultR ?? 0}
                      onBlur={(ev) => {
                        const v = Number(ev.target.value);
                        if (isFinite(v) && v !== e.resultR) handleREdit(e, ev.target.value);
                      }}
                      className="h-7 w-24 border-zinc-800 bg-zinc-900 text-xs font-bold"
                      dir="ltr"
                      aria-label="نتیجه معامله بر حسب R"
                    />
                    {e.closedAt && (
                      <span className="text-[10px] text-zinc-600">
                        بسته‌شده: {new Date(e.closedAt).toLocaleDateString("fa-IR")}
                      </span>
                    )}
                  </div>
                )}

                {e.summary && <p className="mt-2 line-clamp-2 text-[11px] leading-4 text-zinc-500">{e.summary}</p>}
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
