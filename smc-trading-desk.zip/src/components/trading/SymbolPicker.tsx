"use client";

import { useMemo, useState } from "react";
import { Check, ChevronsUpDown, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import type { SymbolInfo } from "@/lib/types";

interface Props {
  symbols: SymbolInfo[];
  value: string;
  onChange: (symbol: string) => void;
  disabled?: boolean;
}

export default function SymbolPicker({ symbols, value, onChange, disabled }: Props) {
  const [open, setOpen] = useState(false);
  const current = symbols.find((s) => s.symbol === value);

  const grouped = useMemo(() => {
    const map = new Map<string, SymbolInfo[]>();
    for (const s of symbols) {
      const key = s.symbol.endsWith("=X") || s.symbol.includes("=") || s.symbol.includes("=F") ? "فارکس و کالا" : "نماد";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(s);
    }
    return map;
  }, [symbols]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          disabled={disabled}
          className="w-full justify-between border-zinc-800 bg-zinc-900 font-normal sm:w-64"
          aria-label="انتخاب نماد"
        >
          <span className="flex min-w-0 items-center gap-2">
            <Search className="h-4 w-4 shrink-0 text-zinc-500" />
            <span className="truncate" dir="ltr">
              {current ? `${current.symbol}` : "انتخاب نماد"}
            </span>
            <span className="truncate text-zinc-500">{current?.name ?? ""}</span>
          </span>
          <ChevronsUpDown className="ms-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 border-zinc-800 bg-zinc-950 p-0" align="start">
        <Command>
          <CommandInput placeholder="جستجوی نماد یا نام..." className="text-zinc-200" />
          <CommandList className="max-h-72">
            <CommandEmpty>نمادی پیدا نشد.</CommandEmpty>
            {[...grouped.entries()].map(([group, items]) => (
              <CommandGroup key={group} heading={group}>
                {items.map((s) => (
                  <CommandItem
                    key={s.symbol}
                    value={`${s.symbol} ${s.name}`}
                    onSelect={() => {
                      onChange(s.symbol);
                      setOpen(false);
                    }}
                    className="justify-between"
                  >
                    <span className="flex items-center gap-2">
                      <Check className={`h-4 w-4 ${s.symbol === value ? "opacity-100" : "opacity-0"}`} />
                      <span dir="ltr" className="font-mono text-sm">
                        {s.symbol}
                      </span>
                    </span>
                    <span className="text-zinc-500">{s.name}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            ))}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
