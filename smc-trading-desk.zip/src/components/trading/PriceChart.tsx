"use client";

import { useEffect, useRef } from "react";
import {
  createChart,
  CandlestickSeries,
  HistogramSeries,
  LineStyle,
  ColorType,
  CrosshairMode,
  type IChartApi,
  type ISeriesApi,
  type IPriceLine,
  type UTCTimestamp,
} from "lightweight-charts";
import type { Candle, Signal } from "@/lib/types";

export interface ChartLevels {
  entryMin: number;
  entryMax: number;
  stopLoss: number;
  targets: number[];
  signal: Signal;
}

interface Props {
  candles: Candle[];
  liquidityLevels: { price: number; type: "above" | "below" }[];
  levels: ChartLevels | null;
}

const GREEN = "#10b981";
const RED = "#ef4444";
const ZINC_LINE = "#27272a";

const fmtTehran = (opts: Intl.DateTimeFormatOptions) => (t: number) =>
  new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Tehran", ...opts }).format(new Date(t * 1000));

export default function PriceChart({ candles, liquidityLevels, levels }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const volRef = useRef<ISeriesApi<"Histogram"> | null>(null);
  const priceLinesRef = useRef<IPriceLine[]>([]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const chart = createChart(el, {
      autoSize: true,
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: "#a1a1aa",
        fontFamily: "Vazirmatn, Tahoma, sans-serif",
        attributionLogo: false,
      },
      grid: {
        vertLines: { color: "rgba(39,39,42,0.5)" },
        horzLines: { color: "rgba(39,39,42,0.5)" },
      },
      crosshair: { mode: CrosshairMode.Normal },
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        borderColor: ZINC_LINE,
        tickMarkFormatter: (t: number) => fmtTehran({ month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" })(t),
      },
      rightPriceScale: { borderColor: ZINC_LINE },
      localization: {
        timeFormatter: (t: number) => fmtTehran({ year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" })(t),
        priceFormatter: (p: number) => (p >= 1000 ? p.toLocaleString("en-US", { maximumFractionDigits: 0 }) : p.toPrecision(6)),
      },
    });

    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: GREEN,
      downColor: RED,
      borderVisible: false,
      wickUpColor: GREEN,
      wickDownColor: RED,
    });

    const volSeries = chart.addSeries(HistogramSeries, {
      priceFormat: { type: "volume" },
      priceScaleId: "vol",
      color: "rgba(113,113,122,0.4)",
    });
    volSeries.priceScale().applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });

    chartRef.current = chart;
    candleRef.current = candleSeries;
    volRef.current = volSeries;

    return () => {
      chart.remove();
      chartRef.current = null;
      candleRef.current = null;
      volRef.current = null;
      priceLinesRef.current = [];
    };
  }, []);

  useEffect(() => {
    const candleSeries = candleRef.current;
    const volSeries = volRef.current;
    const chart = chartRef.current;
    if (!candleSeries || !volSeries || !chart || candles.length === 0) return;

    candleSeries.setData(
      candles.map((c) => ({
        time: c.time as UTCTimestamp,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }))
    );
    volSeries.setData(
      candles.map((c) => ({
        time: c.time as UTCTimestamp,
        value: c.volume,
        color: c.close >= c.open ? "rgba(16,185,129,0.3)" : "rgba(239,68,68,0.3)",
      }))
    );
    chart.timeScale().fitContent();
  }, [candles]);

  useEffect(() => {
    const candleSeries = candleRef.current;
    if (!candleSeries) return;
    for (const pl of priceLinesRef.current) {
      try {
        candleSeries.removePriceLine(pl);
      } catch {
        /* noop */
      }
    }
    priceLinesRef.current = [];

    // خطوط نقدینگی (استخرهای نشکسته)
    for (const l of liquidityLevels) {
      if (!isFinite(l.price) || l.price <= 0) continue;
      priceLinesRef.current.push(
        candleSeries.createPriceLine({
          price: l.price,
          color: "#eab308",
          lineWidth: 1,
          lineStyle: LineStyle.Dotted,
          axisLabelVisible: true,
          title: "LQ",
        })
      );
    }

    if (!levels) return;
    const add = (price: number, color: string, title: string, style: LineStyle) => {
      if (!isFinite(price) || price <= 0) return;
      priceLinesRef.current.push(
        candleSeries.createPriceLine({
          price,
          color,
          lineWidth: 1,
          lineStyle: style,
          axisLabelVisible: true,
          title,
        })
      );
    };

    add(levels.entryMin, "#22d3ee", "ورود ▼", LineStyle.Solid);
    add(levels.entryMax, "#22d3ee", "ورود ▲", LineStyle.Solid);
    add(levels.stopLoss, RED, "حد ضرر", LineStyle.Solid);
    levels.targets.forEach((t, i) => add(t, GREEN, `هدف ${i + 1}`, LineStyle.Dashed));
  }, [liquidityLevels, levels]);

  return <div ref={containerRef} dir="ltr" className="h-[420px] w-full md:h-[520px]" />;
}
