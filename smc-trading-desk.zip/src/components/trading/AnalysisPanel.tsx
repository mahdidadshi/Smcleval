"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Separator } from "@/components/ui/separator";
import { useState, useEffect, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  BrainCircuit,
  TrendingDown,
  TrendingUp,
  Minus,
  Sparkles,
  ShieldAlert,
  Target,
  LogIn,
  Layers,
  Waves,
  Droplets,
  BarChart3,
  RefreshCw,
  CheckCircle2,
  XCircle,
  CircleMinus,
  ListChecks,
  Loader2,
  Save,
} from "lucide-react";
import type { AnalysisResponse, Signal } from "@/lib/types";

export const SIGNAL_FA: Record<Signal, string> = {
  strong_buy: "خرید قوی",
  buy: "خرید",
  neutral: "خنثی",
  sell: "فروش",
  strong_sell: "فروش قوی",
};

export const SIGNAL_STYLE: Record<Signal, { bg: string; text: string; border: string }> = {
  strong_buy: { bg: "bg-emerald-500/15", text: "text-emerald-400", border: "border-emerald-500/40" },
  buy: { bg: "bg-emerald-500/10", text: "text-emerald-300", border: "border-emerald-500/30" },
  neutral: { bg: "bg-zinc-500/10", text: "text-zinc-300", border: "border-zinc-500/30" },
  sell: { bg: "bg-red-500/10", text: "text-red-300", border: "border-red-500/30" },
  strong_sell: { bg: "bg-red-500/15", text: "text-red-400", border: "border-red-500/40" },
};

export function fmtPrice(v: number): string {
  if (!isFinite(v)) return "-";
  const abs = Math.abs(v);
  if (abs >= 1000) return v.toLocaleString("en-US", { maximumFractionDigits: 2 });
  if (abs >= 10) return v.toFixed(2);
  if (abs >= 1) return v.toFixed(3);
  return v.toPrecision(4);
}

function SignalIcon({ signal, className }: { signal: Signal; className?: string }) {
  if (signal === "strong_buy" || signal === "buy") return <TrendingUp className={className} />;
  if (signal === "strong_sell" || signal === "sell") return <TrendingDown className={className} />;
  return <Minus className={className} />;
}

/* ─────────────────── چک‌لیست تأییدیه‌های SMC (همپوشانی ستاپ) ─────────────────── */

type CheckStatus = "ok" | "bad" | "na";

interface CheckItem {
  label: string;
  status: CheckStatus;
  detail: string;
}

function buildConfluence(analysis: AnalysisResponse): CheckItem[] {
  const { agent, smc: s, styles } = analysis;
  const isBuy = agent.signal === "buy" || agent.signal === "strong_buy";
  const isSell = agent.signal === "sell" || agent.signal === "strong_sell";
  if (!isBuy && !isSell) return []; // پلن خنثی — چک‌لیست جهت‌دار معنا ندارد
  const dir: "bull" | "bear" = isBuy ? "bull" : "bear";
  const items: CheckItem[] = [];

  // ۱) شکار تازه نقدینگی همسو — طلا‌ترین تأییدیه
  const freshSweep = s.recentSweeps.find((w) => w.dir === dir && w.barsAgo <= 8);
  const anySweep = s.recentSweeps.find((w) => w.dir === dir);
  if (freshSweep) {
    items.push({ label: "شکار تازه نقدینگی همسو", status: "ok", detail: `${freshSweep.kind} در ${fmtPrice(freshSweep.price)} — ${freshSweep.barsAgo} کندل قبل` });
  } else if (anySweep) {
    items.push({ label: "شکار نقدینگی همسو (بدون تازگی)", status: "na", detail: `${anySweep.barsAgo} کندل قبل — سوخت حرکت مصرف شده است` });
  } else {
    items.push({ label: "شکار تازه نقدینگی همسو", status: "bad", detail: "شکار همسویی در ۱۵ کندل اخیر دیده نشد" });
  }

  // ۲) روند ساختاری
  const trendDir = s.trend === "bullish" ? "bull" : s.trend === "bearish" ? "bear" : null;
  if (trendDir === dir) {
    items.push({ label: "روند ساختاری همسو", status: "ok", detail: s.trend === "bullish" ? "صعودی (ساختار HH/HL)" : "نزولی (ساختار LH/LL)" });
  } else if (trendDir) {
    items.push({ label: "روند ساختاری مخالف", status: "bad", detail: "روند کلی خلاف جهت پلن است — حجم کمتر و خروج سریع‌تر" });
  } else {
    items.push({ label: "روند ساختاری", status: "na", detail: "بازار در فاز رنج است" });
  }

  // ۳) رویداد ساختاری تازه (BOS/CHoCH)
  const ev = s.lastEvent;
  if (ev && ev.dir === dir && ev.barsAgo <= 10) {
    items.push({ label: `رویداد ساختاری ${ev.type} تازه`, status: "ok", detail: `${ev.dir === "bull" ? "صعودی" : "نزولی"} — ${ev.barsAgo} کندل قبل` });
  } else if (ev && ev.dir === dir) {
    items.push({ label: `رویداد ساختاری ${ev.type}`, status: "na", detail: `${ev.barsAgo} کندل قبل — تازگی لازم را ندارد` });
  } else if (ev) {
    items.push({ label: "رویداد ساختاری مخالف", status: "bad", detail: `${ev.type} ${ev.dir === "bull" ? "صعودی" : "نزولی"} — ${ev.barsAgo} کندل قبل` });
  } else {
    items.push({ label: "رویداد ساختاری", status: "na", detail: "BOS/CHoCH اخیری ثبت نشده" });
  }

  // ۴) پرمیوم / دیسکانت نسبت به جهت پلن
  const zone = s.premiumDiscount.zone;
  if (isBuy) {
    if (zone === "discount") items.push({ label: "قیمت در دیسکانت", status: "ok", detail: "خرید در ناحیه تخفیف رنج معاملاتی — کیفیت ورود بالا" });
    else if (zone === "equilibrium") items.push({ label: "قیمت در تعادل", status: "na", detail: "وسط رنج معاملاتی — ورود متوسط" });
    else items.push({ label: "قیمت در پرمیوم", status: "bad", detail: "خرید در ناحیه گران — ریسک پولبک عمیق" });
  } else {
    if (zone === "premium") items.push({ label: "قیمت در پرمیوم", status: "ok", detail: "فروش در ناحیه گران رنج معاملاتی — کیفیت ورود بالا" });
    else if (zone === "equilibrium") items.push({ label: "قیمت در تعادل", status: "na", detail: "وسط رنج معاملاتی — ورود متوسط" });
    else items.push({ label: "قیمت در دیسکانت", status: "bad", detail: "فروش در ناحیه ارزان — ریسک بازگشت شدید" });
  }

  // ۵) هم‌جهتی دلتای والیوم
  const d = s.volume.delta10;
  const volAgree = isBuy ? d > 8 : d < -8;
  const volOppose = isBuy ? d < -8 : d > 8;
  if (volAgree) items.push({ label: "دلتای والیوم همسو", status: "ok", detail: `فشار ${isBuy ? "خرید" : "فروش"} غالب است (${d >= 0 ? "+" : ""}${d.toFixed(0)})` });
  else if (volOppose) items.push({ label: "دلتای والیوم مخالف", status: "bad", detail: `فشار سمت مخالف غالب است (${d >= 0 ? "+" : ""}${d.toFixed(0)})` });
  else items.push({ label: "دلتای والیوم خنثی", status: "na", detail: `تعادل خرید و فروش (${d >= 0 ? "+" : ""}${d.toFixed(0)})` });

  // ۶) زون نهادی همسو در دسترس (اردربلاک / FVG)
  const instType = isBuy ? "bull" : "bear";
  const sameType = [...s.obs, ...s.fvgs].filter((z) => z.type === instType);
  const price = analysis.lastPrice;
  const reachable = sameType.filter((z) => Math.abs((z.top + z.bottom) / 2 - price) <= 1.5 * s.avgRange);
  if (sameType.length === 0) {
    items.push({ label: "زون نهادی همسو", status: "bad", detail: "اردربلاک/FVG همسوی نشکسته‌ای وجود ندارد" });
  } else if (reachable.length > 0) {
    items.push({ label: "زون نهادی همسو در دسترس", status: "ok", detail: `${reachable.length} ناحیه اردربلاک/FVG نزدیک قیمت — پشتیبان ستاپ` });
  } else {
    items.push({ label: "زون نهادی همسو", status: "na", detail: "ناحیه همسو وجود دارد ولی از قیمت دور است" });
  }

  // ۷) فاز چرخه بازار (Wyckoff)
  const cyc = s.cyclePhase;
  const cycBull = cyc.includes("فنر") || cyc.includes("مارکاپ") || cyc.includes("انباشت");
  const cycBear = cyc.includes("آپثراست") || cyc.includes("مارک‌داون") || cyc.includes("توزیع");
  if ((isBuy && cycBull) || (isSell && cycBear)) {
    items.push({ label: "فاز چرخه بازار همسو", status: "ok", detail: cyc });
  } else if (cyc.includes("نامشخص")) {
    items.push({ label: "فاز چرخه بازار", status: "na", detail: "نامشخص — دیتای کافی نیست" });
  } else if ((isBuy && cycBear) || (isSell && cycBull)) {
    items.push({ label: "فاز چرخه بازار مخالف", status: "bad", detail: cyc });
  } else {
    items.push({ label: "فاز چرخه بازار", status: "na", detail: cyc });
  }

  // ۸) هم‌سویی سبک‌های تحلیلی
  const agree = styles.filter((st) => (isBuy ? st.score > 8 : st.score < -8)).length;
  const oppose = styles.filter((st) => (isBuy ? st.score < -8 : st.score > 8)).length;
  if (agree >= 4 && agree > oppose) {
    items.push({ label: "هم‌سویی سبک‌های تحلیل", status: "ok", detail: `${agree} سبک موافق، ${oppose} سبک مخالف` });
  } else if (oppose > agree) {
    items.push({ label: "سبک‌های تحلیل در تضاد", status: "bad", detail: `${oppose} سبک مخالف، ${agree} سبک موافق — احتیاط` });
  } else {
    items.push({ label: "هم‌سویی سبک‌های تحلیل", status: "na", detail: `${agree} موافق، ${oppose} مخالف — اجماع ضعیف` });
  }

  return items;
}

function CheckIcon({ status }: { status: CheckStatus }) {
  if (status === "ok") return <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />;
  if (status === "bad") return <XCircle className="h-4 w-4 shrink-0 text-red-400" />;
  return <CircleMinus className="h-4 w-4 shrink-0 text-zinc-500" />;
}

function ConfluenceChecklist({ items }: { items: CheckItem[] }) {
  if (items.length === 0) {
    return (
      <p className="rounded-md border border-zinc-700/60 bg-zinc-800/40 px-3 py-2.5 text-xs leading-5 text-zinc-400">
        پلن فعلی «خنثی» است؛ چک‌لیست تأییدیه فقط برای پلن‌های جهت‌دار (خرید/فروش) محاسبه می‌شود. تا شکار نقدینگی یا شکست ساختاری صبر کنید.
      </p>
    );
  }
  const ok = items.filter((i) => i.status === "ok").length;
  const bad = items.filter((i) => i.status === "bad").length;
  const quality =
    ok >= 4 && bad <= 1
      ? { text: "کیفیت ستاپ بالا", cls: "text-emerald-400" }
      : ok > bad
        ? { text: "کیفیت ستاپ متوسط", cls: "text-amber-400" }
        : { text: "کیفیت ستاپ ضعیف", cls: "text-red-400" };
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-md bg-zinc-800/50 px-3 py-2">
        <span className="text-xs text-zinc-400">
          <span className="font-extrabold text-emerald-400">{ok}</span> تأیید
          <span className="mx-2 text-zinc-600">|</span>
          <span className="font-extrabold text-red-400">{bad}</span> تضاد
          <span className="mx-2 text-zinc-600">|</span>
          <span className="font-extrabold text-zinc-300">{items.length - ok - bad}</span> خنثی
        </span>
        <span className={`text-xs font-extrabold ${quality.cls}`}>{quality.text}</span>
      </div>
      <ul className="space-y-1.5">
        {items.map((it, i) => (
          <li key={i} className="flex items-start gap-2 rounded-md border border-zinc-800 bg-zinc-900/50 px-2.5 py-2">
            <span className="mt-0.5">
              <CheckIcon status={it.status} />
            </span>
            <div className="min-w-0">
              <p className={`text-xs font-bold ${it.status === "ok" ? "text-zinc-100" : it.status === "bad" ? "text-zinc-300" : "text-zinc-400"}`}>{it.label}</p>
              <p className="text-[11px] leading-4 text-zinc-500">{it.detail}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

interface Props {
  analysis: AnalysisResponse;
  onPlanSaved?: () => void;
}

export default function AnalysisPanel({ analysis, onPlanSaved }: Props) {
  const { agent, techScore, styles, smc: s } = analysis;
  const sig = SIGNAL_STYLE[agent.signal];
  const scorePct = Math.round(((techScore + 100) / 200) * 100);
  const isBuy = agent.signal === "buy" || agent.signal === "strong_buy";
  const isSell = agent.signal === "sell" || agent.signal === "strong_sell";
  const isDirectional = isBuy || isSell;
  const checklist = useMemo(() => buildConfluence(analysis), [analysis]);

  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [savedFor, setSavedFor] = useState<number | null>(null);
  useEffect(() => {
    setSavedFor(null);
  }, [analysis.generatedAt, analysis.symbol, analysis.timeframe]);

  async function handleSavePlan() {
    if (saving || savedFor != null) return;
    setSaving(true);
    try {
      const res = await fetch("/api/journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: analysis.symbol,
          symbolName: analysis.symbolName,
          market: analysis.market,
          timeframe: analysis.timeframe,
          direction: isBuy ? "long" : isSell ? "short" : "neutral",
          entryMin: agent.entryMin,
          entryMax: agent.entryMax,
          stopLoss: agent.stopLoss,
          targets: agent.targets,
          confidence: agent.confidence,
          riskReward: agent.riskReward,
          summary: agent.summary,
        }),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || "خطا در ذخیره پلن");
      }
      setSavedFor(analysis.generatedAt);
      toast({
        title: "پلن معاملاتی در ژورنال ذخیره شد",
        description: `${analysis.symbolName} — ${SIGNAL_FA[agent.signal]} (${analysis.timeframe})`,
      });
      onPlanSaved?.();
    } catch (e) {
      toast({
        title: "ذخیره پلن ناموفق بود",
        description: e instanceof Error ? e.message : "خطای نامشخص",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      {/* پلن معاملاتی */}
      <Card className="border-zinc-800 bg-zinc-900/60">
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <BrainCircuit className="h-5 w-5 text-emerald-400" />
              پلن معاملاتی اسمارت مانی
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={`${agent.source === "ai" ? "border-emerald-600/50 text-emerald-400" : "border-amber-600/50 text-amber-400"} gap-1`}>
                <Sparkles className="h-3 w-3" />
                {agent.source === "ai" ? "هوش مصنوعی" : "سیستمی"}
              </Badge>
              <Button
                size="sm"
                onClick={handleSavePlan}
                disabled={saving || savedFor != null || !isDirectional}
                title={isDirectional ? "ذخیره این پلن در ژورنال معاملات" : "پلن خنثی قابل ذخیره نیست"}
                className="h-8 gap-1.5 bg-emerald-600 px-3 text-xs font-bold hover:bg-emerald-500"
              >
                {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                {savedFor != null ? "ذخیره شد ✓" : "ذخیره در ژورنال"}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className={`flex items-center gap-2 rounded-lg border px-4 py-2 ${sig.bg} ${sig.border}`}>
              <SignalIcon signal={agent.signal} className={`h-6 w-6 ${sig.text}`} />
              <span className={`text-xl font-extrabold ${sig.text}`}>{SIGNAL_FA[agent.signal]}</span>
            </div>
            <div className="flex-1" dir="ltr">
              <div className="mb-1 flex items-center justify-between text-xs text-zinc-400">
                <span>اطمینان</span>
                <span className="font-bold text-zinc-200">{agent.confidence}٪</span>
              </div>
              <Progress value={agent.confidence} className="h-2 bg-zinc-800" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="rounded-md border border-cyan-500/25 bg-cyan-500/5 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-xs text-cyan-300/90">
                <LogIn className="h-3.5 w-3.5" /> محدوده ورود ({agent.entryType === "limit" ? "لیمیت" : "مارکت"})
              </div>
              <div className="font-mono text-xs font-bold text-cyan-200" dir="ltr">
                {fmtPrice(agent.entryMin)} — {fmtPrice(agent.entryMax)}
              </div>
            </div>
            <div className="rounded-md border border-red-500/25 bg-red-500/5 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-xs text-red-300/90">
                <ShieldAlert className="h-3.5 w-3.5" /> حد ضرر (پشت نقدینگی)
              </div>
              <div className="font-mono text-xs font-bold text-red-200" dir="ltr">
                {fmtPrice(agent.stopLoss)}
              </div>
            </div>
            {agent.targets.map((t, i) => {
              const dist = ((t - analysis.lastPrice) / analysis.lastPrice) * 100;
              return (
                <div key={i} className="rounded-md border border-emerald-500/25 bg-emerald-500/5 p-2.5">
                  <div className="mb-1 flex items-center gap-1.5 text-xs text-emerald-300/90">
                    <Target className="h-3.5 w-3.5" /> هدف {i + 1} (نقدینگی)
                  </div>
                  <div className="font-mono text-xs font-bold text-emerald-200" dir="ltr">
                    {fmtPrice(t)} <span className="text-emerald-400/70">({dist > 0 ? "+" : ""}{dist.toFixed(1)}٪)</span>
                  </div>
                </div>
              );
            })}
            <div className="col-span-2 flex items-center justify-between rounded-md border border-zinc-700/60 bg-zinc-800/40 px-3 py-2">
              <span className="flex items-center gap-1.5 text-xs text-zinc-400">
                <Layers className="h-3.5 w-3.5" /> نسبت ریسک به بازده
              </span>
              <Badge variant="secondary" className="bg-zinc-800 font-mono text-zinc-200" dir="ltr">
                1 : {agent.riskReward.toFixed(2)}
              </Badge>
            </div>
          </div>

          <Separator className="bg-zinc-800" />
          <p className="text-sm leading-6 text-zinc-300">{agent.summary}</p>
          {agent.reasoning.length > 0 && (
            <ul className="space-y-1.5">
              {agent.reasoning.map((r, i) => (
                <li key={i} className="flex items-start gap-2 text-xs leading-5 text-zinc-400">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />
                  {r}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* چک‌لیست تأییدیه‌ها */}
      <Card className="border-zinc-800 bg-zinc-900/60">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm">
            <ListChecks className="h-4 w-4 text-cyan-400" /> چک‌لیست تأییدیه‌های SMC
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ConfluenceChecklist items={checklist} />
        </CardContent>
      </Card>

      {/* امتیاز ترکیبی */}
      <Card className="border-zinc-800 bg-zinc-900/60">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">امتیاز ترکیبی (۷ سبک اسمارت مانی)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2" dir="ltr">
          <div className="relative h-3 overflow-hidden rounded-full bg-gradient-to-r from-red-600/70 via-zinc-700 to-emerald-600/70">
            <div
              className="absolute top-1/2 h-5 w-1.5 -translate-y-1/2 rounded-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]"
              style={{ left: `calc(${scorePct}% - 3px)` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-zinc-500">
            <span>فروش قوی -۱۰۰</span>
            <span className="font-bold text-zinc-300">{techScore >= 0 ? "+" : ""}{techScore.toFixed(0)}</span>
            <span>+۱۰۰ خرید قوی</span>
          </div>
        </CardContent>
      </Card>

      {/* ساختار و چرخه */}
      <Card className="border-zinc-800 bg-zinc-900/60">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Waves className="h-4 w-4 text-amber-400" /> ساختار، چرخه و سشن‌ها
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-xs">
          <div className="flex items-center justify-between rounded-md bg-zinc-800/50 px-2.5 py-2">
            <span className="text-zinc-500">روند ساختاری</span>
            <span className={`font-bold ${s.trend === "bullish" ? "text-emerald-400" : s.trend === "bearish" ? "text-red-400" : "text-zinc-300"}`}>
              {s.trend === "bullish" ? "صعودی (HH/HL)" : s.trend === "bearish" ? "نزولی (LH/LL)" : "رنج"}
            </span>
          </div>
          <div className="flex items-center justify-between rounded-md bg-zinc-800/50 px-2.5 py-2">
            <span className="text-zinc-500">آخرین رویداد ساختار</span>
            {s.lastEvent ? (
              <span className={`font-bold ${s.lastEvent.dir === "bull" ? "text-emerald-400" : "text-red-400"}`} dir="rtl">
                {s.lastEvent.type} {s.lastEvent.dir === "bull" ? "صعودی" : "نزولی"} ({s.lastEvent.barsAgo} کندل قبل)
              </span>
            ) : (
              <span className="text-zinc-400">—</span>
            )}
          </div>
          <div className="flex items-center justify-between rounded-md bg-zinc-800/50 px-2.5 py-2">
            <span className="text-zinc-500">فاز چرخه بازار</span>
            <span className="font-bold text-amber-300">{s.cyclePhase}</span>
          </div>
          <div className="flex items-center justify-between rounded-md bg-zinc-800/50 px-2.5 py-2">
            <span className="text-zinc-500">پرمیوم / دیسکانت</span>
            <span className={`font-bold ${s.premiumDiscount.zone === "discount" ? "text-emerald-400" : s.premiumDiscount.zone === "premium" ? "text-red-400" : "text-zinc-300"}`}>
              {s.premiumDiscount.zone === "discount" ? "دیسکانت (ناحیه خرید)" : s.premiumDiscount.zone === "premium" ? "پرمیوم (ناحیه فروش)" : "تعادل"}
            </span>
          </div>
          {s.sessions && (
            <div className="flex items-center justify-between rounded-md bg-zinc-800/50 px-2.5 py-2">
              <span className="text-zinc-500">سشن و کیل‌زون</span>
              <span className="font-bold text-zinc-200">
                {s.sessions.sessionName}
                {s.sessions.killzone ? <span className="text-amber-400"> ⚡ کیل‌زون</span> : ""}
              </span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* نقدینگی و تله‌ها */}
      <Card className="border-zinc-800 bg-zinc-900/60">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Droplets className="h-4 w-4 text-yellow-400" /> نقدینگی و تله‌های روانی
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <p className="mb-1.5 text-[11px] font-bold text-zinc-500">استخرهای نقدینگی نشکسته (اهداف احتمالی قیمت)</p>
            <div className="flex flex-wrap gap-1.5" dir="ltr">
              {s.poolsAbove.slice(0, 3).map((p, i) => (
                <Badge key={`a${i}`} variant="outline" className="border-amber-500/30 bg-amber-500/5 font-mono text-[11px] text-amber-300">
                  ▲ {fmtPrice(p.price)} ({p.touches}x)
                </Badge>
              ))}
            </div>
            <div className="my-1.5 flex items-center gap-2 text-[10px] text-zinc-600">
              <span className="h-px flex-1 bg-zinc-800" />
              <span className="font-mono text-zinc-400" dir="ltr">{fmtPrice(analysis.lastPrice)}</span>
              <span className="h-px flex-1 bg-zinc-800" />
            </div>
            <div className="flex flex-wrap gap-1.5" dir="ltr">
              {s.poolsBelow.slice(0, 3).map((p, i) => (
                <Badge key={`b${i}`} variant="outline" className="border-amber-500/30 bg-amber-500/5 font-mono text-[11px] text-amber-300">
                  ▼ {fmtPrice(p.price)} ({p.touches}x)
                </Badge>
              ))}
            </div>
          </div>

          {s.recentSweeps.length > 0 && (
            <div className="space-y-1">
              <p className="text-[11px] font-bold text-zinc-500">شکارهای اخیر نقدینگی</p>
              {s.recentSweeps.map((w, i) => (
                <p key={i} className={`text-xs leading-5 ${w.dir === "bull" ? "text-emerald-300" : "text-red-300"}`}>
                  • {w.kind} در سطح {fmtPrice(w.price)} ({w.barsAgo} کندل قبل) — سیگنال {w.dir === "bull" ? "صعودی" : "نزولی"}
                </p>
              ))}
            </div>
          )}

          {s.traps.length > 0 && (
            <div className="space-y-1">
              <p className="text-[11px] font-bold text-zinc-500">تله‌های شناسایی‌شده</p>
              {s.traps.map((t, i) => (
                <p key={i} className={`text-xs leading-5 ${t.dir === "bull" ? "text-emerald-300" : "text-red-300"}`}>
                  • {t.name} ({t.barsAgo} کندل قبل)
                </p>
              ))}
            </div>
          )}

          {s.roundLevel != null && (
            <p className="text-xs text-zinc-400">
              سطح روانی عدد رند: <span className="font-mono text-zinc-200" dir="ltr">{fmtPrice(s.roundLevel)}</span>
            </p>
          )}
        </CardContent>
      </Card>

      {/* والیوم */}
      <Card className="border-zinc-800 bg-zinc-900/60">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm">
            <BarChart3 className="h-4 w-4 text-purple-400" /> والیوم تریدینگ
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-2" dir="ltr">
            <div className="flex items-center justify-between rounded-md bg-zinc-800/50 px-2.5 py-2">
              <span className="text-zinc-500">POC</span>
              <span className="font-mono font-bold text-purple-300">{fmtPrice(s.volume.poc)}</span>
            </div>
            <div className="flex items-center justify-between rounded-md bg-zinc-800/50 px-2.5 py-2">
              <span className="text-zinc-500">قیمت vs POC</span>
              <span className={`font-bold ${s.volume.priceVsPoc === "above" ? "text-emerald-400" : "text-red-400"}`}>
                {s.volume.priceVsPoc === "above" ? "بالا" : "پایین"}
              </span>
            </div>
            <div className="flex items-center justify-between rounded-md bg-zinc-800/50 px-2.5 py-2">
              <span className="text-zinc-500">حجم/میانگین</span>
              <span className={`font-mono font-bold ${s.volume.volumeRatio > 1.8 ? "text-amber-400" : "text-zinc-200"}`}>
                {s.volume.volumeRatio.toFixed(2)}x
              </span>
            </div>
            <div className="flex items-center justify-between rounded-md bg-zinc-800/50 px-2.5 py-2">
              <span className="text-zinc-500">کلایمکس</span>
              {s.volume.climax ? (
                <span className={`font-bold ${s.volume.climax.dir === "bull" ? "text-emerald-400" : "text-red-400"}`}>
                  {s.volume.climax.dir === "bull" ? "صعودی" : "نزولی"}
                </span>
              ) : (
                <span className="text-zinc-400">—</span>
              )}
            </div>
          </div>
          <div dir="ltr">
            <div className="mb-1 flex justify-between text-[10px] text-zinc-500">
              <span>دلتای والیوم (۱۰ کندل)</span>
              <span className={s.volume.delta10 >= 0 ? "font-bold text-emerald-400" : "font-bold text-red-400"}>
                {s.volume.delta10 >= 0 ? "+" : ""}{s.volume.delta10.toFixed(0)}
              </span>
            </div>
            <div className="relative h-2.5 rounded-full bg-gradient-to-r from-red-600/70 via-zinc-700 to-emerald-600/70">
              <div
                className="absolute top-1/2 h-4 w-1.5 -translate-y-1/2 rounded-full bg-white"
                style={{ left: `calc(${((s.volume.delta10 + 100) / 200) * 100}% - 3px)` }}
              />
            </div>
          </div>
          {s.volume.absorption && (
            <p className={`text-xs leading-5 ${s.volume.absorption.dir === "bull" ? "text-emerald-300" : "text-red-300"}`}>
              جذب سفارش (Absorption) {s.volume.absorption.dir === "bull" ? "صعودی" : "نزولی"} شناسایی شد — والیوم بالا بدون پیشرفت قیمت.
            </p>
          )}
        </CardContent>
      </Card>

      {/* اردربلاک و FVG */}
      <Card className="border-zinc-800 bg-zinc-900/60">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm">
            <RefreshCw className="h-4 w-4 text-cyan-400" /> اردربلاک و FVG نشکسته (سبک ICT)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2" dir="ltr">
          {s.obs.length === 0 && s.fvgs.length === 0 && (
            <p className="text-xs text-zinc-500" dir="rtl">منطقه نهادی نشکسته‌ای در ۹۰ کندل اخیر یافت نشد.</p>
          )}
          {s.obs.slice(0, 3).map((o, i) => (
            <div key={`ob${i}`} className="flex items-center justify-between rounded-md border border-zinc-800 bg-zinc-800/40 px-2.5 py-2">
              <span className={`text-[11px] font-bold ${o.type === "bull" ? "text-emerald-300" : "text-red-300"}`} dir="rtl">
                اردربلاک {o.type === "bull" ? "صعودی" : "نزولی"}
              </span>
              <span className="font-mono text-[11px] text-zinc-300">
                {fmtPrice(o.bottom)} — {fmtPrice(o.top)}
              </span>
            </div>
          ))}
          {s.fvgs.slice(0, 3).map((f, i) => (
            <div key={`fvg${i}`} className="flex items-center justify-between rounded-md border border-zinc-800 bg-zinc-800/40 px-2.5 py-2">
              <span className={`text-[11px] font-bold ${f.type === "bull" ? "text-emerald-300" : "text-red-300"}`} dir="rtl">
                FVG {f.type === "bull" ? "صعودی" : "نزولی"}
              </span>
              <span className="font-mono text-[11px] text-zinc-300">
                {fmtPrice(f.bottom)} — {fmtPrice(f.top)}
              </span>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* سبک‌ها */}
      <Card className="border-zinc-800 bg-zinc-900/60">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">تفکیک سبک‌های تحلیل</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="multiple" defaultValue={["s0", "s1"]}>
            {styles.map((st, i) => {
              const stl = SIGNAL_STYLE[st.signal];
              return (
                <AccordionItem key={st.id} value={`s${i}`} className="border-zinc-800">
                  <AccordionTrigger className="py-2.5 hover:no-underline">
                    <span className="flex w-full items-center justify-between gap-2">
                      <span className="text-sm">{st.name}</span>
                      <span className="flex items-center gap-2">
                        <span className="font-mono text-xs text-zinc-500" dir="ltr">
                          {st.score >= 0 ? "+" : ""}{st.score.toFixed(0)}
                        </span>
                        <Badge variant="outline" className={`${stl.bg} ${stl.text} ${stl.border} gap-1 px-2 py-0.5 text-[11px]`}>
                          <SignalIcon signal={st.signal} className="h-3 w-3" />
                          {SIGNAL_FA[st.signal]}
                        </Badge>
                      </span>
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-1.5 pb-3">
                    {st.reasons.map((r, j) => (
                      <p key={j} className="text-xs leading-5 text-zinc-400">
                        • {r}
                      </p>
                    ))}
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
