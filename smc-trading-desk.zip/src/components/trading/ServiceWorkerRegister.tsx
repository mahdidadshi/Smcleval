"use client";

import { useEffect } from "react";

// ثبت سرویس‌ورکر برای قابلیت نصب و کار آفلاین (PWA)
export default function ServiceWorkerRegister() {
  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;
    const register = () => {
      navigator.serviceWorker.register("/sw.js").catch(() => {
        /* نصب سرویس‌ورکر اختیاری است؛ خطا بی‌صدا نادیده گرفته می‌شود */
      });
    };
    if (document.readyState === "complete") {
      register();
      return;
    }
    window.addEventListener("load", register, { once: true });
    return () => window.removeEventListener("load", register);
  }, []);

  return null;
}
