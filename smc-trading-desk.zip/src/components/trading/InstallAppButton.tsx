"use client";

import { useEffect, useState, useSyncExternalStore } from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

type NavigatorStandalone = Navigator & { standalone?: boolean };

// وضعیت نصب‌شده بودن (استندآلون) به‌صورت reactive — بدون setState داخل effect
function subscribeStandalone(cb: () => void) {
  const mq = window.matchMedia("(display-mode: standalone)");
  mq.addEventListener("change", cb);
  return () => mq.removeEventListener("change", cb);
}
function getStandaloneSnapshot() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    (window.navigator as NavigatorStandalone).standalone === true
  );
}
function getStandaloneServerSnapshot() {
  return false;
}

// دکمه «نصب برنامه»: در کروم/اج/ادج به‌محض آماده شدن پرامپت نصب نمایش داده می‌شود.
// در iOS سافاری پرامپت مرورگر وجود ندارد و کاربر از منوی «Add to Home Screen» نصب می‌کند.
export default function InstallAppButton() {
  const [promptEvent, setPromptEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const standalone = useSyncExternalStore(subscribeStandalone, getStandaloneSnapshot, getStandaloneServerSnapshot);

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setPromptEvent(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => setPromptEvent(null);
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (!promptEvent || standalone) return null;

  return (
    <Button
      size="sm"
      onClick={() => {
        promptEvent
          .prompt()
          .then(() => setPromptEvent(null))
          .catch(() => {});
      }}
      className="gap-1.5 bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-500/30 hover:bg-emerald-500/25 hover:text-emerald-200"
      aria-label="نصب برنامه روی دستگاه"
    >
      <Download className="h-4 w-4" />
      نصب برنامه
    </Button>
  );
}
