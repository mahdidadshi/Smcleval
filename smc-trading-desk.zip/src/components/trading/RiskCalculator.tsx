"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calculator, TrendingDown, TrendingUp, Wallet, Percent, Scale, Gauge } from "lucide-react";
import type { AgentVerdict, Market } from "@/lib/types";

function fmtPrice(v: number): string {
  if (!isFinite(v)) return "-";
  const abs = Math.abs(v);
  if (abs >= 1000) return v.toFixed(2);
  if (abs >= 1) return v.toFixed(3);
  return v.toPrecision(4);
}

function fmtQty(v: number): string {
  if (!isFinite(v) || v <= 0) return "-";
  if (v >= 100000) return v.toLocaleString("en-US", { maximumFractionDigits: 0 });
  if (v >= 1000) return v.toLocaleString("en-US", { maximumFractionDigits: 1 });
  if (v >= 1) return v.toFixed(3);
  return v.toPrecision(3);
}

function fmtMoney(v: number): string {
  if (!isFinite(v)) return "-";
  return v.toLocaleString("en-US", { maximumFractionDigits: 2 });
}

const UNIT_LABEL: Record<Market, string> = {
  crypto: "واحد رمزارز",
  stock: "سهم",
  forex: "واحد پایه",
};

interface Props {
  agent: AgentVerdict;
  market: Market;
  lastPrice: number;
}

export default function RiskCalculator({ agent, market }: Props) {
  const [balance, setBalance] = useState("1000");
  const [riskPct, setRiskPct] = useState("1");
  const agentIsBuy = agent.signal === "buy" || agent.signal === "strong_buy";
  const agentIsSell = agent.signal === "sell" || agent.signal === "strong_sell";
  const [manualDir, setManualDir] = useState<"long" | "short">("long");
  const dir = agentIsBuy ? "long" : agentIsSell ? "short" : manualDir;
  const isLong = dir === "long";

  const calc = useMemo(() => {
    const bal = Number(balance);
    const pct = Number(riskPct);
    if (!isFinite(bal) || bal <= 0 || !isFinite(pct) || pct <= 0) return null;
    const entryMid = (agent.entryMin + agent.entryMax) / 2;
    const stopDist = Math.abs(entryMid - agent.stopLoss);
    if (stopDist <= 0 || !isFinite(stopDist)) return null;
    const riskAmount = (bal * pct) / 100;
    const units = riskAmount / stopDist;
    const positionValue = units * entryMid;
    const leverage = positionValue / bal;
    const profits = agent.targets.map((t) => ({
      price: t,
      money: units * Math.abs(t - entryMid),
      r: Math.abs(t - entryMid) / stopDist,
      pct: (Math.abs(t - entryMid) / entryMid) * 100,
    }));
    return {
      entryMid,
      stopDist,
      riskAmount,
      units,
      positionValue,
      leverage,
      profits,
      stopPct: (stopDist / entryMid) * 100,
    };
  }, [balance, riskPct, agent]);

  const riskInputCls = "h-9 border-zinc-800 bg-zinc-900 text-sm font-bold text-zinc-100";

  return (
    <Card className="border-zinc-800 bg-zinc-900/60">
      <CardHeader className="pb-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Calculator className="h-4 w-4 text-violet-400" />
            ماشین‌حساب مدیریت سرمایه
          </CardTitle>
          {agentIsBuy || agentIsSell ? (
            <span className={`flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] font-bold ${isLong ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-red-500/40 bg-red-500/10 text-red-300"}`}>
              {isLong ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              جهت پلن ایجنت: {isLong ? "خرید" : "فروش"}
            </span>
          ) : (
            <div className="flex rounded-md border border-zinc-800 bg-zinc-900 p-0.5">
              {(["long", "short"] as const).map((d) => (
                <button
                  key={d}
                  onClick={() => setManualDir(d)}
                  className={`rounded px-2.5 py-1 text-[11px] font-bold transition-colors ${
                    dir === d
                      ? d === "long"
                        ? "bg-emerald-500/15 text-emerald-400"
                        : "bg-red-500/15 text-red-400"
                      : "text-zinc-500 hover:text-zinc-300"
                  }`}
                >
                  {d === "long" ? "خرید" : "فروش"}
                </button>
              ))}
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-xs text-zinc-400">
              <Wallet className="h-3.5 w-3.5" /> موجودی حساب ($)
            </label>
            <Input
              type="number"
              min="1"
              value={balance}
              onChange={(e) => setBalance(e.target.value)}
              className={riskInputCls}
              dir="ltr"
              aria-label="موجودی حساب به دلار"
            />
          </div>
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-xs text-zinc-400">
              <Percent className="h-3.5 w-3.5" /> ریسک هر معامله (٪)
            </label>
            <Input
              type="number"
              min="0.1"
              step="0.1"
              value={riskPct}
              onChange={(e) => setRiskPct(e.target.value)}
              className={riskInputCls}
              dir="ltr"
              aria-label="درصد ریسک هر معامله"
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {["0.5", "1", "2", "3"].map((p) => (
            <Button
              key={p}
              size="sm"
              variant="outline"
              onClick={() => setRiskPct(p)}
              className={`h-7 border-zinc-800 px-2.5 text-[11px] font-bold ${riskPct === p ? "border-violet-500/50 bg-violet-500/15 text-violet-300" : "bg-zinc-900 text-zinc-400"}`}
            >
              {p}٪
            </Button>
          ))}
          <span className="ms-auto self-center text-[10px] text-zinc-600">مبنا: میانگین محدوده ورود پلن</span>
        </div>

        {!calc ? (
          <p className="rounded-md border border-amber-500/25 bg-amber-500/5 px-3 py-2.5 text-xs leading-5 text-amber-300">
            موجودی و درصد ریسک را با اعداد مثبت وارد کنید تا حجم پوزیشن محاسبه شود.
          </p>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-md border border-red-500/25 bg-red-500/5 p-2.5">
                <p className="mb-1 text-[11px] text-red-300/80">مبلغ در معرض ریسک</p>
                <p className="font-mono text-sm font-extrabold text-red-200" dir="ltr">
                  ${fmtMoney(calc.riskAmount)}
                </p>
                <p className="mt-0.5 text-[10px] text-zinc-500">
                  فاصله استاپ: <span className="font-mono" dir="ltr">{fmtPrice(calc.stopDist)}</span> ({calc.stopPct.toFixed(2)}٪)
                </p>
              </div>
              <div className="rounded-md border border-violet-500/25 bg-violet-500/5 p-2.5">
                <p className="mb-1 flex items-center gap-1 text-[11px] text-violet-300/80">
                  <Scale className="h-3 w-3" /> حجم پوزیشن ({UNIT_LABEL[market]})
                </p>
                <p className="font-mono text-sm font-extrabold text-violet-200" dir="ltr">
                  {fmtQty(calc.units)}
                </p>
                <p className="mt-0.5 text-[10px] text-zinc-500">
                  ارزش: <span className="font-mono" dir="ltr">${fmtMoney(calc.positionValue)}</span>
                </p>
              </div>
            </div>

            {calc.leverage > 1.05 && (
              <div className="flex items-center justify-between rounded-md border border-amber-500/25 bg-amber-500/5 px-3 py-2">
                <span className="flex items-center gap-1.5 text-xs text-amber-300">
                  <Gauge className="h-3.5 w-3.5" />
                  ارزش پوزیشن از موجودی بزرگ‌تر است — اهرم لازم:
                </span>
                <span className={`font-mono text-sm font-extrabold ${calc.leverage > 10 ? "text-red-300" : "text-amber-200"}`} dir="ltr">
                  ×{calc.leverage.toFixed(1)}
                </span>
              </div>
            )}

            <div className="space-y-1.5">
              <p className="text-[11px] font-bold text-zinc-500">سود/ضرر پیش‌بینی‌شده در اهداف پلن:</p>
              {calc.profits.map((p, i) => (
                <div key={i} className="flex items-center justify-between rounded-md border border-emerald-500/20 bg-emerald-500/5 px-3 py-2">
                  <span className="text-xs text-emerald-300/90">
                    هدف {i + 1}: <span className="font-mono font-bold" dir="ltr">{fmtPrice(p.price)}</span>
                    <span className="text-emerald-500/70"> (+{p.pct.toFixed(2)}٪)</span>
                  </span>
                  <span className="flex items-center gap-2 font-mono text-xs font-extrabold" dir="ltr">
                    <span className="text-emerald-300">+${fmtMoney(p.money)}</span>
                    <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[10px] text-emerald-300">{p.r.toFixed(2)}R</span>
                  </span>
                </div>
              ))}
              <div className="flex items-center justify-between rounded-md border border-zinc-700/50 bg-zinc-800/40 px-3 py-2">
                <span className="text-xs text-zinc-400">
                  در صورت خوردن استاپ: <span className="font-mono font-bold" dir="ltr">{fmtPrice(agent.stopLoss)}</span>
                </span>
                <span className="font-mono text-xs font-extrabold text-red-300" dir="ltr">
                  −${fmtMoney(calc.riskAmount)} (−۱R)
                </span>
              </div>
            </div>
            <p className="text-[10px] leading-4 text-zinc-600">
              حجم پوزیشن = (موجودی × ریسک٪) ÷ فاصله استاپ. برای فارکس/کالا این عدد «واحد پایه» است و بسته به بروکر/لوریج باید تبدیل شود؛ همیشه قبل از ثبت سفارش، حجم نهایی را در پلتفرم خود چک کنید.
            </p>
          </>
        )}
      </CardContent>
    </Card>
  );
}
