import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import ServiceWorkerRegister from "@/components/trading/ServiceWorkerRegister";

export const metadata: Metadata = {
  title: "میز کار ایجنت اسمارت مانی (SMC) | پلن معامله، مدیریت ریسک و ژورنال",
  description:
    "اپلیکیشن کاربردی تحلیل معاملات با روش اسمارت مانی: پلن معاملاتی کامل (ورود، حد ضرر، اهداف)، چک‌لیست تأییدیه‌های SMC، ماشین‌حساب حجم پوزیشن و مدیریت ریسک و ژورنال معاملات با آمار عملکرد — روی چارت کریپتو، سهام و فارکس.",
  applicationName: "میزکار SMC",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    title: "میزکار SMC",
    statusBarStyle: "black-translucent",
  },
  formatDetection: { telephone: false },
  icons: {
    icon: [
      { url: "/icons/icon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: "/icons/apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#09090b",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" className="dark" suppressHydrationWarning>
      <head>
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css"
        />
      </head>
      <body className="antialiased bg-zinc-950 text-zinc-100 [font-family:Vazirmatn,Tahoma,Arial,sans-serif]">
        {children}
        <Toaster />
        <ServiceWorkerRegister />
      </body>
    </html>
  );
}
