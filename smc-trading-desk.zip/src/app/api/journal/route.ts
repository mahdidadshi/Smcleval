import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

const STATUSES = ["open", "win", "loss", "breakeven", "cancelled"] as const;

let schemaReady: Promise<void> | null = null;

// اطمینان از وجود جدول ژورنال — برای دیتابیس ابری تازه (مثل Turso) بدون نیاز به مایگریشن دستی
// DDL دقیقاً مطابق خروجی prisma db push است
function ensureSchema(): Promise<void> {
  schemaReady ??= (async () => {
    await db.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS "TradePlan" (
        "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updatedAt" DATETIME NOT NULL,
        "symbol" TEXT NOT NULL,
        "symbolName" TEXT NOT NULL,
        "market" TEXT NOT NULL,
        "timeframe" TEXT NOT NULL,
        "direction" TEXT NOT NULL,
        "entryMin" REAL NOT NULL,
        "entryMax" REAL NOT NULL,
        "stopLoss" REAL NOT NULL,
        "targets" TEXT NOT NULL,
        "confidence" INTEGER NOT NULL,
        "riskReward" REAL NOT NULL,
        "summary" TEXT NOT NULL,
        "note" TEXT,
        "status" TEXT NOT NULL DEFAULT 'open',
        "resultR" REAL,
        "closedAt" DATETIME
      )
    `);
    await db.$executeRawUnsafe(
      `CREATE INDEX IF NOT EXISTS "TradePlan_createdAt_idx" ON "TradePlan"("createdAt" DESC)`
    );
  })();
  return schemaReady;
}

/** آمار عملکرد از روی کل رکوردهای بسته‌شده + مجموع R */
function computeStats(entries: { status: string; resultR: number | null; riskReward: number }[]) {
  const closed = entries.filter((e) => e.status === "win" || e.status === "loss" || e.status === "breakeven");
  const wins = closed.filter((e) => e.status === "win").length;
  const losses = closed.filter((e) => e.status === "loss").length;
  const breakevens = closed.filter((e) => e.status === "breakeven").length;
  const totalR = closed.reduce((sum, e) => sum + (e.resultR ?? 0), 0);
  const avgPlannedRr =
    closed.length > 0 ? closed.reduce((sum, e) => sum + e.riskReward, 0) / closed.length : 0;
  return {
    total: entries.length,
    open: entries.filter((e) => e.status === "open").length,
    closed: closed.length,
    wins,
    losses,
    breakevens,
    winRate: closed.length > 0 ? Math.round((wins / closed.length) * 100) : 0,
    totalR: Number(totalR.toFixed(2)),
    avgPlannedRr: Number(avgPlannedRr.toFixed(2)),
  };
}

export async function GET() {
  try {
    await ensureSchema();
    const rows = await db.tradePlan.findMany({ orderBy: { createdAt: "desc" }, take: 200 });
    const entries = rows.map((r) => ({
      ...r,
      targets: JSON.parse(r.targets || "[]") as number[],
    }));
    return NextResponse.json({ entries, stats: computeStats(entries) });
  } catch (err) {
    console.error("[journal:GET]", err);
    return NextResponse.json({ error: "خطا در خواندن ژورنال معاملات" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSchema();
    const body = await req.json();
    const { symbol, symbolName, market, timeframe, direction, entryMin, entryMax, stopLoss, targets, confidence, riskReward, summary, note } = body;

    if (!symbol || !direction || !Array.isArray(targets)) {
      return NextResponse.json({ error: "داده پلن ناقص است." }, { status: 400 });
    }
    if (direction !== "long" && direction !== "short" && direction !== "neutral") {
      return NextResponse.json({ error: "جهت معامله نامعتبر است." }, { status: 400 });
    }

    const entry = await db.tradePlan.create({
      data: {
        symbol: String(symbol),
        symbolName: String(symbolName ?? symbol),
        market: String(market ?? "crypto"),
        timeframe: String(timeframe ?? "1h"),
        direction: String(direction),
        entryMin: Number(entryMin),
        entryMax: Number(entryMax),
        stopLoss: Number(stopLoss),
        targets: JSON.stringify(targets),
        confidence: Math.round(Number(confidence) || 0),
        riskReward: Number(riskReward) || 0,
        summary: String(summary ?? ""),
        note: note ? String(note) : null,
        status: "open",
      },
    });
    return NextResponse.json({ entry }, { status: 201 });
  } catch (err) {
    console.error("[journal:POST]", err);
    return NextResponse.json({ error: "خطا در ذخیره پلن معاملاتی" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    await ensureSchema();
    const body = await req.json();
    const id = Number(body.id);
    if (!Number.isInteger(id) || id <= 0) {
      return NextResponse.json({ error: "شناسه پلن نامعتبر است." }, { status: 400 });
    }
    const existing = await db.tradePlan.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: "پلن یافت نشد." }, { status: 404 });

    const data: { status?: string; resultR?: number | null; note?: string | null; closedAt?: Date | null } = {};
    if (typeof body.status === "string") {
      if (!STATUSES.includes(body.status as (typeof STATUSES)[number])) {
        return NextResponse.json({ error: "وضعیت نامعتبر است." }, { status: 400 });
      }
      data.status = body.status;
      data.closedAt = body.status === "open" ? null : new Date();
    }
    if (body.resultR !== undefined) {
      data.resultR = body.resultR === null || body.resultR === "" ? null : Number(body.resultR);
      if (data.resultR !== null && !isFinite(data.resultR)) {
        return NextResponse.json({ error: "مقدار R نامعتبر است." }, { status: 400 });
      }
    }
    if (body.note !== undefined) data.note = body.note ? String(body.note) : null;

    const entry = await db.tradePlan.update({ where: { id }, data });
    return NextResponse.json({ entry });
  } catch (err) {
    console.error("[journal:PATCH]", err);
    return NextResponse.json({ error: "خطا در به‌روزرسانی پلن" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = Number(req.nextUrl.searchParams.get("id"));
    if (!Number.isInteger(id) || id <= 0) {
      return NextResponse.json({ error: "شناسه پلن نامعتبر است." }, { status: 400 });
    }
    await db.tradePlan.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[journal:DELETE]", err);
    return NextResponse.json({ error: "خطا در حذف پلن" }, { status: 500 });
  }
}
