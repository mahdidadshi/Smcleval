import { NextRequest, NextResponse } from "next/server";
import { getSymbolName, getCandles, SYMBOLS, ALL_TFS } from "@/lib/market-data";
import { aggregateScore, runAllStyles } from "@/lib/styles";
import { analyzeSmc } from "@/lib/smc";
import { runAgent } from "@/lib/agent";
import type { AnalysisResponse, Market, Timeframe } from "@/lib/types";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const MARKETS: Market[] = ["crypto", "stock", "forex"];

export async function GET(req: NextRequest) {
  try {
    const market = (req.nextUrl.searchParams.get("market") ?? "crypto") as Market;
    const symbol = req.nextUrl.searchParams.get("symbol") ?? "BTCUSDT";
    const tf = (req.nextUrl.searchParams.get("tf") ?? "1h") as Timeframe;

    if (!MARKETS.includes(market) || !ALL_TFS.includes(tf) || !SYMBOLS[market].some((s) => s.symbol === symbol)) {
      return NextResponse.json({ error: "پارامترهای درخواست نامعتبر است." }, { status: 400 });
    }

    const candles = await getCandles(market, symbol, tf);
    const smcBundle = analyzeSmc(candles, tf);
    const styles = runAllStyles(smcBundle.snapshot);
    const techScore = aggregateScore(styles);
    const agent = await runAgent({
      symbol,
      symbolName: getSymbolName(market, symbol),
      timeframe: tf,
      lastPrice: candles[candles.length - 1].close,
      smc: smcBundle.snapshot,
      styles,
      techScore,
    });
    const body: AnalysisResponse = {
      symbol,
      symbolName: getSymbolName(market, symbol),
      market,
      timeframe: tf,
      lastPrice: candles[candles.length - 1].close,
      styles,
      techScore,
      smc: smcBundle.snapshot,
      agent,
      generatedAt: Date.now(),
    };
    return NextResponse.json(body);
  } catch (err) {
    console.error("[analyze]", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "خطا در تحلیل" },
      { status: 500 }
    );
  }
}
