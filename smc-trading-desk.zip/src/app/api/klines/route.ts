import { NextRequest, NextResponse } from "next/server";
import { buildQuote, getSymbolName, getCandles, SYMBOLS, ALL_TFS } from "@/lib/market-data";
import { analyzeSmc } from "@/lib/smc";
import type { KlinesResponse, Market, Timeframe } from "@/lib/types";

export const dynamic = "force-dynamic";

const MARKETS: Market[] = ["crypto", "stock", "forex"];

export async function GET(req: NextRequest) {
  try {
    const market = (req.nextUrl.searchParams.get("market") ?? "crypto") as Market;
    const symbol = req.nextUrl.searchParams.get("symbol") ?? "BTCUSDT";
    const tf = (req.nextUrl.searchParams.get("tf") ?? "1h") as Timeframe;

    if (!MARKETS.includes(market) || !ALL_TFS.includes(tf) || !SYMBOLS[market].some((s) => s.symbol === symbol)) {
      return NextResponse.json({ error: "پارامترهای درخواست نامعتبر است." }, { status: 400 });
    }

    const candles = await getCandles(market, symbol, tf);
    const smc = analyzeSmc(candles, tf);

    const liquidityLevels = [
      ...smc.snapshot.poolsAbove.slice(0, 3).map((p) => ({ price: p.price, type: "above" as const })),
      ...smc.snapshot.poolsBelow.slice(0, 3).map((p) => ({ price: p.price, type: "below" as const })),
    ];

    const body: KlinesResponse = {
      symbol,
      market,
      timeframe: tf,
      candles,
      liquidityLevels,
      quote: buildQuote(candles),
    };
    void getSymbolName(market, symbol);
    return NextResponse.json(body);
  } catch (err) {
    console.error("[klines]", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "خطا در دریافت دیتای بازار" },
      { status: 500 }
    );
  }
}
