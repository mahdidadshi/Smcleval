"use client";

import { useCallback, useEffect, useState } from "react";
import { Bitcoin, Building2, CandlestickChart, Coins, Globe2, Loader2, RefreshCcw, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import PriceChart, { type ChartLevels } from "@/components/trading/PriceChart";
import SymbolPicker from "@/components/trading/SymbolPicker";
import AnalysisPanel, { SIGNAL_FA, SIGNAL_STYLE, fmtPrice } from "@/components/trading/AnalysisPanel";
import RiskCalculator from "@/components/trading/RiskCalculator";
import TradeJournal from "@/components/trading/TradeJournal";
import InstallAppButton from "@/components/trading/InstallAppButton";
import { SYMBOLS } from "@/lib/symbols-client";
import type { AnalysisResponse, KlinesResponse, Market, Timeframe } from "@/lib/types";

const MARKET_META: { id: Market; label: string; icon: React.ReactNode }[] = [
  { id: "crypto", label: "کریپتو", icon: <Bitcoin className="h-4 w-4" /> },
  { id: "stock", label: "سهام آمریکا", icon: <Building2 className="h-4 w-4" /> },
  { id: "forex", label: "فارکس و کالا", icon: <Coins className="h-4 w-4" /> },
];

const TIMEFRAMES: { id: Timeframe; label: string }[] = [
  { id: "1m", label: "۱ دقیقه" },
  { id: "5m", label: "۵ دقیقه" },
  { id: "15m", label: "۱۵ دقیقه" },
  { id: "30m", label: "۳۰ دقیقه" },
  { id: "1h", label: "۱ ساعت" },
  { id: "4h", label: "۴ ساعت" },
  { id: "1d", label: "روزانه" },
  { id: "1w", label: "هفتگی" },
];

export default function Home() {
  const [market, setMarket] = useState<Market>("crypto");
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [tf, setTf] = useState<Timeframe>("15m");
  const [klines, setKlines] = useState<KlinesResponse | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const [loadingKlines, setLoadingKlines] = useState(true);
  const [loadingAnalysis, setLoadingAnalysis] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [journalKey, setJournalKey] = useState(0);

  useEffect(() => {
    const ctrl = new AbortController();
    async function load() {
      setLoadingKlines(true);
      setLoadingAnalysis(true);
      setError(null);
      try {
        const kRes = await fetch(`/api/klines?market=${market}&symbol=${encodeURIComponent(symbol)}&tf=${tf}`, {
          signal: ctrl.signal,
        });
        if (!kRes.ok) {
          const j = await kRes.json().catch(() => ({}));
          throw new Error(j.error || "خطا در دریافت دیتای چارت");
        }
        setKlines(await kRes.json());
        setLoadingKlines(false);

        const aRes = await fetch(`/api/analyze?market=${market}&symbol=${encodeURIComponent(symbol)}&tf=${tf}`, {
          signal: ctrl.signal,
        });
        if (!aRes.ok) {
          const j = await aRes.json().catch(() => ({}));
          throw new Error(j.error || "خطا در تحلیل ایجنت");
        }
        setAnalysis(await aRes.json());
      } catch (e) {
        if (e instanceof DOMException && e.name === "AbortError") return;
        setError(e instanceof Error ? e.message : "خطای نامشخص");
      } finally {
        setLoadingKlines(false);
        setLoadingAnalysis(false);
      }
    }
    load();
    return () => ctrl.abort();
  }, [market, symbol, tf, refreshKey]);

  const handleMarketChange = useCallback((m: Market) => {
    setMarket(m);
    setSymbol(SYMBOLS[m][0].symbol);
    setAnalysis(null);
    setKlines(null);
  }, []);

  const levels: ChartLevels | null =
    analysis && analysis.symbol === symbol && analysis.timeframe === tf
      ? {
          entryMin: analysis.agent.entryMin,
          entryMax: analysis.agent.entryMax,
          stopLoss: analysis.agent.stopLoss,
          targets: analysis.agent.targets,
          signal: analysis.agent.signal,
        }
      : null;

  const quote = klines?.quote;
  const quoteUp = (quote?.changePct ?? 0) >= 0;

  return (
    <div className="flex min-h-screen flex-col bg-zinc-950 text-zinc-100">
      <header className="sticky top-0 z-20 border-b border-zinc-800 bg-zinc-950/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/15 ring-1 ring-emerald-500/30">
              <CandlestickChart className="h-5 w-5 text-emerald-400" />
            </div>
            <div>
              <h1 className="text-base font-extrabold leading-tight sm:text-lg">میز کار ایجنت اسمارت مانی (SMC)</h1>
              <p className="text-[11px] text-zinc-500">تحلیل نقدینگی و ساختار، پلن معاملاتی، مدیریت ریسک و ژورنال عملکرد</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden items-center gap-2 text-xs text-zinc-500 sm:flex">
              <Globe2 className="h-3.5 w-3.5" />
              <span>دیتا: Binance / Yahoo Finance</span>
            </div>
            <InstallAppButton />
            <Button
              variant="outline"
              size="icon"
              onClick={() => setRefreshKey((k) => k + 1)}
              disabled={loadingKlines || loadingAnalysis}
              aria-label="به‌روزرسانی"
              className="border-zinc-800 bg-zinc-900"
            >
              <RefreshCcw className={`h-4 w-4 ${loadingAnalysis ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-4">
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <div className="flex rounded-lg border border-zinc-800 bg-zinc-900 p-1">
            {MARKET_META.map((m) => (
              <button
                key={m.id}
                onClick={() => handleMarketChange(m.id)}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-bold transition-colors sm:text-sm ${
                  market === m.id ? "bg-emerald-500/15 text-emerald-400" : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                {m.icon}
                {m.label}
              </button>
            ))}
          </div>
          <SymbolPicker symbols={SYMBOLS[market]} value={symbol} onChange={(s) => { setSymbol(s); setAnalysis(null); }} />
          <div className="flex rounded-lg border border-zinc-800 bg-zinc-900 p-1">
            {TIMEFRAMES.map((t) => (
              <button
                key={t.id}
                onClick={() => setTf(t.id)}
                className={`rounded-md px-2.5 py-1.5 text-xs font-bold transition-colors sm:text-sm ${
                  tf === t.id ? "bg-emerald-500/15 text-emerald-400" : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {quote && (
          <div className="mb-4 flex flex-wrap items-center gap-x-6 gap-y-1 rounded-xl border border-zinc-800 bg-zinc-900/60 px-4 py-2.5">
            <span className="font-mono text-xl font-extrabold sm:text-2xl" dir="ltr">
              {fmtPrice(quote.last)}
            </span>
            <span className={`font-mono text-sm font-bold ${quoteUp ? "text-emerald-400" : "text-red-400"}`} dir="ltr">
              {quoteUp ? "▲" : "▼"} {Math.abs(quote.changePct).toFixed(2)}٪
            </span>
            <span className="text-xs text-zinc-500">
              سقف ۴۰ کندل: <span className="font-mono text-zinc-300" dir="ltr">{fmtPrice(quote.periodHigh)}</span>
            </span>
            <span className="text-xs text-zinc-500">
              کف ۴۰ کندل: <span className="font-mono text-zinc-300" dir="ltr">{fmtPrice(quote.periodLow)}</span>
            </span>
            {analysis && (
              <span className="ms-auto flex flex-wrap items-center gap-x-4 gap-y-1">
                <span className="flex items-center gap-1.5 text-xs">
                  <span className="text-zinc-500">امتیاز SMC:</span>
                  <span className={`font-mono font-bold ${analysis.techScore >= 25 ? "text-emerald-400" : analysis.techScore <= -25 ? "text-red-400" : "text-zinc-300"}`} dir="ltr">
                    {analysis.techScore >= 0 ? "+" : ""}{analysis.techScore.toFixed(0)}
                  </span>
                </span>
                <span className="flex items-center gap-1.5 text-xs">
                  <span className="text-zinc-500">پلن ایجنت:</span>
                  <span className={`font-bold ${SIGNAL_STYLE[analysis.agent.signal].text}`}>
                    {SIGNAL_FA[analysis.agent.signal]}
                  </span>
                </span>
              </span>
            )}
          </div>
        )}

        {error && (
          <Card className="mb-4 border-red-500/30 bg-red-500/5">
            <CardContent className="flex items-center gap-3 p-4">
              <TriangleAlert className="h-5 w-5 shrink-0 text-red-400" />
              <p className="text-sm text-red-300">{error}</p>
              <Button variant="outline" size="sm" className="ms-auto border-zinc-700" onClick={() => setRefreshKey((k) => k + 1)}>
                تلاش دوباره
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="grid gap-4 lg:grid-cols-3">
          <section className="lg:col-span-2" aria-label="چارت قیمت">
            <Card className="overflow-hidden border-zinc-800 bg-zinc-900/60">
              <CardContent className="p-3 sm:p-4">
                <div className="mb-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-zinc-500" dir="ltr">
                  <span className="flex items-center gap-1.5"><span className="h-0.5 w-4 rounded bg-yellow-500" /> نقدینگی نشکسته (LQ)</span>
                  <span className="flex items-center gap-1.5"><span className="h-0.5 w-4 rounded bg-cyan-400" /> ورود</span>
                  <span className="flex items-center gap-1.5"><span className="h-0.5 w-4 rounded bg-red-500" /> حد ضرر</span>
                  <span className="flex items-center gap-1.5"><span className="h-0.5 w-4 rounded bg-emerald-500" /> اهداف (نقدینگی)</span>
                </div>
                {loadingKlines || !klines ? (
                  <Skeleton className="h-[420px] w-full animate-pulse bg-zinc-800/70 md:h-[520px]" />
                ) : (
                  <PriceChart
                    candles={klines.candles}
                    liquidityLevels={klines.liquidityLevels}
                    levels={levels}
                  />
                )}
              </CardContent>
            </Card>
          </section>

          <section aria-label="پنل تحلیل">
            {loadingAnalysis && !analysis ? (
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-center gap-3 rounded-xl border border-emerald-500/20 bg-emerald-500/5 px-4 py-8">
                  <Loader2 className="h-5 w-5 animate-spin text-emerald-400" />
                  <div>
                    <p className="text-sm font-bold text-emerald-300">ایجنت در حال ساخت پلن معاملاتی...</p>
                    <p className="text-xs text-zinc-500">اسکن نقدینگی، ساختار، تله‌ها، سشن‌ها و پروفایل والیوم</p>
                  </div>
                </div>
                {[0, 1, 2].map((i) => (
                  <Skeleton key={i} className="h-40 w-full animate-pulse bg-zinc-800/70" />
                ))}
              </div>
            ) : analysis ? (
              <AnalysisPanel analysis={analysis} onPlanSaved={() => setJournalKey((k) => k + 1)} />
            ) : null}
          </section>
        </div>

        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          <section aria-label="مدیریت سرمایه">
            {analysis ? (
              <RiskCalculator agent={analysis.agent} market={analysis.market} lastPrice={analysis.lastPrice} />
            ) : (
              <Skeleton className="h-80 w-full animate-pulse bg-zinc-800/70" />
            )}
          </section>
          <section aria-label="ژورنال معاملات">
            <TradeJournal refreshKey={journalKey} currentPrice={quote?.last} currentSymbol={symbol} />
          </section>
        </div>
      </main>

      <footer className="mt-auto border-t border-zinc-800 bg-zinc-950 pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto max-w-7xl px-4 py-3 text-center text-[11px] leading-5 text-zinc-600">
          این میز کار صرفاً ابزار آموزشی و تحلیل خودکار اسمارت مانی (SMC/ICT) است و هیچ‌کدام از خروجی‌ها توصیه سرمایه‌گذاری نیستند. مسئولیت استفاده از پلن‌ها، حجم پوزیشن و نتایج ثبت‌شده در ژورنال کاملاً بر عهده خود شماست.
        </div>
      </footer>
    </div>
  );
}
