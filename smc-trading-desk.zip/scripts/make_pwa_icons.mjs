// آیکون‌های PWA میز کار ایجنت اسمارت مانی — تولید با sharp
import sharp from "sharp";
import { mkdirSync } from "fs";

const OUT = "public/icons";
mkdirSync(OUT, { recursive: true });

const BG = "#09090b";
const RED = "#f43f5e";
const GREEN = "#22c55e";
const GOLD = "#eab308";

// بدنه آیکون: خط نقدینگی طلایی نقطه‌چین + سه کندل صعودی (اولی قرمز = شکار نقدینگی)
const content = `
    <path d="M 96 118 L 416 118" stroke="${GOLD}" stroke-width="12" stroke-dasharray="26 18" stroke-linecap="round" opacity="0.95" fill="none"/>
    <line x1="170" y1="188" x2="170" y2="424" stroke="${RED}" stroke-width="12" stroke-linecap="round"/>
    <rect x="134" y="234" width="72" height="148" rx="14" fill="${RED}"/>
    <line x1="276" y1="148" x2="276" y2="392" stroke="${GREEN}" stroke-width="12" stroke-linecap="round"/>
    <rect x="240" y="196" width="72" height="150" rx="14" fill="${GREEN}"/>
    <line x1="380" y1="96" x2="380" y2="348" stroke="${GREEN}" stroke-width="12" stroke-linecap="round"/>
    <rect x="344" y="148" width="72" height="152" rx="14" fill="${GREEN}"/>
`;

// نسخه "any": گوشه گرد با شفافیت بیرون
const anySvg = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
  <rect width="512" height="512" rx="112" fill="${BG}"/>
  <rect x="6" y="6" width="500" height="500" rx="106" fill="none" stroke="#27272a" stroke-width="6" opacity="0.8"/>
  ${content}
</svg>`;

// نسخه "maskable": تمام‌صفحه با محتوا در ناحیه امن میانی
const maskableSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
  <rect width="512" height="512" fill="${BG}"/>
  <g transform="translate(71.7, 71.7) scale(0.72)">
    ${content}
  </g>
</svg>`;

await sharp(Buffer.from(anySvg)).png().toFile(`${OUT}/icon-512.png`);
await sharp(Buffer.from(anySvg)).resize(192, 192).png().toFile(`${OUT}/icon-192.png`);
await sharp(Buffer.from(anySvg)).resize(32, 32).png().toFile(`${OUT}/icon-32.png`);
await sharp(Buffer.from(maskableSvg)).png().toFile(`${OUT}/maskable-512.png`);
await sharp(Buffer.from(maskableSvg)).resize(180, 180).png().toFile(`${OUT}/apple-touch-icon.png`);

console.log("PWA icons generated in", OUT);
