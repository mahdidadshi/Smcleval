// اجرای سرور پروداکشن (خروجی standalone) با اتصال به همه اینترفیس‌ها
// سازگار با ویندوز/مک/لینوکس — چون HOSTNAME را صریح 0.0.0.0 می‌کنیم
process.env.HOSTNAME = "0.0.0.0";

require("../.next/standalone/server.js");
