#!/usr/bin/env bash
# ساخت بسته مستقل «میز کار ایجنت اسمارت مانی» + تست دود کامل + zip نهایی
set -euo pipefail
cd /home/z/my-project

STAGE=/home/z/my-project/.staging/package
ZIP=/home/z/my-project/download/smc-trading-desk.zip

rm -rf /home/z/my-project/.staging
mkdir -p "$STAGE" /home/z/my-project/download

# ─── ۱) کپی پروژه بدون موارد محیط سندباکس ───
rsync -a \
  --exclude node_modules \
  --exclude .next \
  --exclude .git \
  --exclude .staging \
  --exclude download \
  --exclude examples \
  --exclude tests \
  --exclude tool-results \
  --exclude db \
  --exclude dev.log \
  --exclude server.log \
  --exclude Caddyfile \
  --exclude worklog.md \
  --exclude agent-ctx \
  --exclude skills \
  --exclude .zscripts \
  --exclude .zai \
  --exclude upload \
  --exclude mini-services \
  --exclude 'scripts/*.png' \
  ./ "$STAGE"/

# ─── ۲) .env پرتابل: دیتابیس SQLite نسبی ───
cat > "$STAGE/.env" <<'EOF'
DATABASE_URL=file:./dev.db
EOF

# ─── ۳) وصله package.json: نام/نسخه + اسکریپت‌های کراس‌پلتفرم (ویندوز/مک/لینوکس) ───
node -e "
const fs = require('fs');
const p = JSON.parse(fs.readFileSync('$STAGE/package.json', 'utf8'));
p.name = 'smc-trading-desk';
p.version = '1.0.0';
p.scripts = {
  ...p.scripts,
  dev: 'next dev -p 3000',
  build: 'next build && node scripts/postbuild.js',
  start: 'node scripts/start-prod.js',
  postinstall: 'prisma generate'
};
fs.writeFileSync('$STAGE/package.json', JSON.stringify(p, null, 2) + '\n');
console.log('package.json patched:', p.name, p.version);
"

# ─── ۴) تست دود: نصب → بیلد پروداکشن → اجرا بدون db push ───
# دیتابیس عمداً خالی رها می‌شود تا «ساخت خودکار جدول» در journal route هم تست شود (مسیر Turso/کلاود)
cd "$STAGE"
echo "=== [1/3] bun install ==="
bun install 2>&1 | tail -3
echo "=== [2/3] next build (پروداکشن) ==="
CI=1 bun run build 2>&1 | tail -6

echo "=== [3/3] اجرای سرور پروداکشن روی پورت 3456 (دیتابیس نو — تست بوت‌استرپ خودکار) ==="
# DATABASE_URL صریحاً override می‌شود تا ارث‌بری متغیر محیطی سندباکس، تست را آلوده نکند
PORT=3456 DATABASE_URL="file:./dev-smoke.db" node scripts/start-prod.js > server-test.log 2>&1 &
SERVER_PID=$!
sleep 5

CODE=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3456/ || true)
echo "GET / -> $CODE"
if [ "$CODE" != "200" ]; then echo "FAIL: صفحه اصلی 200 نشد"; kill $SERVER_PID 2>/dev/null || true; exit 1; fi

POST_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://127.0.0.1:3456/api/journal \
  -H "Content-Type: application/json" \
  -d '{"symbol":"TESTUSDT","symbolName":"تست بسته","market":"crypto","timeframe":"15m","direction":"long","entryMin":100,"entryMax":101,"stopLoss":99,"targets":[102,103],"confidence":70,"riskReward":2,"summary":"تست سلامت بسته مستقل"}' || true)
echo "POST /api/journal -> $POST_CODE"
if [ "$POST_CODE" != "201" ]; then echo "FAIL: ذخیره ژورنال کار نکرد"; kill $SERVER_PID 2>/dev/null || true; exit 1; fi

JCOUNT=$(curl -s http://127.0.0.1:3456/api/journal | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{const j=JSON.parse(d);console.log(j.entries?(j.entries.some(p=>p.symbol==='TESTUSDT')?'OK':'MISSING'):'NOLIST')})")
echo "GET /api/journal -> $JCOUNT"
if [ "$JCOUNT" != "OK" ]; then echo "FAIL: خواندن ژورنال کار نکرد"; kill $SERVER_PID 2>/dev/null || true; exit 1; fi

kill $SERVER_PID 2>/dev/null || true
sleep 1
echo "=== تست دود کامل پاس شد ✓ ==="

# ─── ۵) پاکسازی قبل از zip (فقط سورس تمیز) ───
cd "$STAGE"
rm -rf node_modules .next prisma/dev.db dev-smoke.db prisma/dev-smoke.db dev.log server.log server-test.log 2>/dev/null || true

# ─── ۶) ساخت zip ───
rm -f "$ZIP"
zip -qr "$ZIP" .
cd /home/z/my-project

echo "=== ZIP READY ==="
ls -lh "$ZIP"
echo "--- تعداد فایل‌ها ---"
unzip -l "$ZIP" | tail -1
rm -rf /home/z/my-project/.staging
