// کپی فایل‌های استاتیک و .env به خروجی standalone بعد از next build
// سازگار با ویندوز / مک / لینوکس (به‌جای cp -r یونیکسی)
const { cpSync, existsSync, copyFileSync } = require("fs");
const path = require("path");

const root = process.cwd();
const standalone = path.join(root, ".next", "standalone");

if (!existsSync(standalone)) {
  console.warn("[postbuild] .next/standalone پیدا نشد — رد شد");
  process.exit(0);
}

cpSync(path.join(root, ".next", "static"), path.join(standalone, ".next", "static"), { recursive: true });

if (existsSync(path.join(root, "public"))) {
  cpSync(path.join(root, "public"), path.join(standalone, "public"), { recursive: true });
}

if (existsSync(path.join(root, ".env"))) {
  copyFileSync(path.join(root, ".env"), path.join(standalone, ".env"));
}

console.log("[postbuild] فایل‌های standalone آماده شد");
