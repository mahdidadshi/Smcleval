#!/usr/bin/env bash
# نصب کامل میز کار ایجنت اسمارت مانی روی سرور اوبونتو (VPS)
# فقط با گوشی + اپ Termius (SSH) هم قابل اجراست: bash install-vps.sh
set -euo pipefail
cd "$(dirname "$0")"

echo "==> [1/5] بررسی Node.js"
if ! command -v node >/dev/null 2>&1 || [ "$(node -v | sed 's/v//' | cut -d. -f1)" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi
node -v

echo "==> [2/5] نصب وابستگی‌ها"
npm install

echo "==> [3/5] ساخت دیتابیس SQLite محلی"
npx prisma db push

echo "==> [4/5] بیلد پروداکشن"
npm run build

echo "==> [5/5] اجرای ۲۴/۷ با pm2"
if ! command -v pm2 >/dev/null 2>&1; then
  sudo npm i -g pm2
fi
pm2 delete smc 2>/dev/null || true
pm2 start scripts/start-prod.js --name smc --time
pm2 save

IP=$(curl -s ifconfig.me 2>/dev/null || echo "SERVER_IP")
echo ""
echo "✅ نصب کامل شد — آدرس برنامه: http://$IP:3000"
echo "   - وضعیت: pm2 status | لاگ: pm2 logs smc"
echo "   - برای شروع خودکار پس از ریبوت، دستور خروجی «pm2 startup» را یک بار اجرا کنید"
echo "   - برای نصب واقعی PWA روی گوشی، دامنه + SSL (Caddy/Nginx) اضافه کنید"
